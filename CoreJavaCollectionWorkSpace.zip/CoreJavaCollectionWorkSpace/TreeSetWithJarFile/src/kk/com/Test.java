package kk.com;

import java.util.Set;
import java.util.TreeSet;

import com.infotech.model.Employee;

public class Test {

	public static void main(String[] args) {
		
		Set<Employee> set = new TreeSet<Employee>(new SortByEmployeeId());
		set.add(new Employee(1001, "Nazish"));
		set.add(new Employee(101, "Ahmad"));
		set.add(new Employee(88, "Kishan"));
		
		for (Employee employee : set) {
			System.out.println(employee);
		}

	}

}
