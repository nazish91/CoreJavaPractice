package kk.com;

public enum Fruits {
MANGO(110),APPLE(200),PINEAPPLE(190);

	private int cost;
	private Fruits(int cost){
		this.cost = cost;
	}
	
	public int getCost() {
		return cost;
	}
}
