package kk.com;

public class Test {

	public static void main(String[] args) {

		Fruits[] values = Fruits.values();
		for (Fruits fruits : values) {
			System.out.println(fruits+"::"+fruits.getCost());
		}
	}

}

