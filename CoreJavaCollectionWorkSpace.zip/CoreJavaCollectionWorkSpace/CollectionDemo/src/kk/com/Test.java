package kk.com;

import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Vector;

public class Test {

	public static void main(String[] args) {

		//List<String> list = new ArrayList<>();
		//List<String> list = new CopyOnWriteArrayList<>();
		List<String> list = new Vector<>();
		list.add("Nazish");
		list.add("Kishan");
		list.add("Ahmad");
		
		Iterator<String> iterator = list.iterator();
		
		System.out.println(list);
		while (iterator.hasNext()) {
			String name = iterator.next();
			System.out.println(name);
		}
		
		System.out.println("---------------------------");
		System.out.println(list);
		
		Object[] array = list.toArray();
		for (Object object : array) {
			System.out.println(object);
		}
		
		String[] array2 = list.toArray(new String[]{});
		for (String name : array2) {
			System.out.println(name);
		}
		
		/*int[] arr = new int[]{1,2,3};
		List<int[]> asList = Arrays.asList(arr);
		for (int[] is : asList) {
			for (int i = 0; i < is.length; i++) {
				System.out.println(is[i]);
			}
		}*/
		
		
		int[] arr = new int[]{1,2,3};
		List<int[]> asList = Arrays.asList(arr);
		for (int[] is : asList) {
				System.out.println(Arrays.toString(is));
		}
		
		
	}
}
