package com.java7.org;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.List;

import com.infotech.model.Welcome;

public class Java7FeaturesTest {

	public static void main(String[] args) {
		//1. Type inference
		//typeInferenceTest();
		
		//2.Under Score in Numeric value
		//numberWithUnderScore();
		
		//3.Try with Resources
		//tryWithResoures();
		
		//4.Try with Resources
		//switchCasesWithString("ADMIN");
		try {
			ExceptionPropagationInJava7();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	//ClassNotFoundException
	//InstantiationException
	//IllegalAccessException
	private static void ExceptionPropagationInJava7() throws ClassNotFoundException,InstantiationException,IllegalAccessException {
		try {
			Class<?> cls = Class.forName("com.infotech.model.Welcome");
			Object obj = cls.newInstance();
			if(obj != null){
				Welcome welcome = (Welcome)obj;
				welcome.welcome();
			}
		} catch (Exception  e) {
			e.printStackTrace();
			throw e;
		}
	}



	private static void switchCasesWithString(String userType) {
		switch (userType) {
		case "ADMIN":System.out.println("User Type is Admin...");
			break;
			
		case "DEV":System.out.println("User Type is DEV...");
		
		break;

		default:
			System.out.println("Invalid user Type..");
			break;
		}
	}

	private static void tryWithResoures() {
		
		try(FileInputStream fileInputStream = new FileInputStream("test.txt");
				FileOutputStream fileOutputStream = new FileOutputStream(new File("test2.txt"))) {
			int data = 0;
			while((data=fileInputStream.read()) != -1){
				fileOutputStream.write((char)data);
			}
			fileOutputStream.flush();
			
			System.out.println("Data is written..");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private static void numberWithUnderScore() {
		//Valid
		long creditCardNo = 1398_6527_9272_7245L;
		float cost = 78_131.237_28_73f;
		
		System.out.println(creditCardNo);
		System.out.println(cost);
		
		//InValid
		//long creditCardNo2 = _1398_6527_9272_7245L;
		//long creditCardNo3 = 1398_6527_9272_7245_L;
		//float cost2 = 78_131_.237_28_73f;
	}

	private static void typeInferenceTest() {
		List<String> list = new ArrayList<>();
		list.add("KK");
		list.add("PK");
	}
}
