package com.infotech.model;

public class Welcome {

	public void welcome(){
		System.out.println("Welcome");
	}
}
