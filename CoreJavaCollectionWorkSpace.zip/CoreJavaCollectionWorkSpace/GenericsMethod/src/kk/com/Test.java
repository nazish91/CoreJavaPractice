package kk.com;

public class Test {

	public static void main(String[] args) {

		Integer intArr[]={1,43,53,64,5};
		itertateArray(intArr);
		System.out.println("--------------------------");
		Character charArr[] ={'X','Y','Z'};
		itertateArray(charArr);
	}

	private static <E> void itertateArray(E[] elemets){
		for (E e : elemets) {
			System.out.println(e);
		}
	}
}
