package kk.com;

import java.util.ArrayList;
import java.util.List;

public class Test {

	public static void main(String[] args) {

		Integer data = 200;
		System.out.println(data);
		List<Integer> list = new ArrayList<>();
		list.add(new Integer(1223));
		list.add(67264);
		
		for (Integer data1 : list) {
			System.out.println(data1);
		}
	}

}
