package kk.com;

/*import static kk.com.Employee.COMPANAYNAME;
import static kk.com.Employee.info;*/
import static kk.com.Employee.*;

public class Test {

	public static void main(String[] args) {

		//System.out.println(Employee.COMPANAYNAME);
		//Employee.info();
		System.out.println(COMPANAYNAME);
		info();
	}

}
