package kk.com;

public class Employee {

	public static final String COMPANAYNAME="WIPRO";
	
	public static void info() {
		System.out.println("Info");
	}
	
	public void dispaly(){
		System.out.println("dispaly");
	}

}
