package com.infotech.client;

import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Map;

public class IdentityHashMapTest {

	public static void main(String[] args) {
		
		String company1="Google";
		String company2= new String("Google");
		String company3 = new String("Google");
		company3 = company2;
		System.out.println(System.identityHashCode(company1));
		System.out.println(company1.hashCode());
		//Map<String,Integer> map = new HashMap<>();
		Map<String,Integer> map = new IdentityHashMap<>();
		map.put(company1, 100000);
		map.put(company2, 10000);
		map.put(company3, 1000);
		
		System.out.println(map);
	}

}
