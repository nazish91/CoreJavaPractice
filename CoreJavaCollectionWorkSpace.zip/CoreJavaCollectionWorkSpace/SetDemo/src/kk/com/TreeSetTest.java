package kk.com;

import java.util.Set;
import java.util.TreeSet;

public class TreeSetTest {

	public static void main(String[] args) {

		//treeSetWithStringObjects();
		treeSetWithCustomObjects();
	}

	private static void treeSetWithCustomObjects() {
		Set<Student> set = new TreeSet<>();
		set.add(new Student(1051, "Nazish"));
		set.add(new Student(1001, "Ahmad"));
		set.add(new Student(901, "Rajesh"));
		
		for (Student student : set) {
			System.out.println(student);
			
		}
		
	}

	private static void treeSetWithStringObjects() {
		Set<String> set = new TreeSet<>();
		//set.add(null);
		set.add("Nazish");
		set.add("Ahmad");
		set.add("Kishan");
		
		for (String name : set) {
			System.out.println(name);
		}
	}

}


class Student implements Comparable<Student>{
	
	private Integer rollNo;
	private String name;
	public Student(Integer rollNo, String name) {
		super();
		this.rollNo = rollNo;
		this.name = name;
	}
	@Override
	public String toString() {
		return "Student [rollNo=" + rollNo + ", name=" + name + "]";
	}
	@Override
	public int compareTo(Student s1) {
		return this.rollNo.compareTo(s1.rollNo);
	}
}