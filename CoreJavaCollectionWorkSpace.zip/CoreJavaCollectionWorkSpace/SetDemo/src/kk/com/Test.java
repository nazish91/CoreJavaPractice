package kk.com;

import java.util.LinkedHashSet;
import java.util.Set;

public class Test {

	public static void main(String[] args) {
//		Set<Employee> empSet = new HashSet<>();
		Set<Employee> empSet = new LinkedHashSet<>();
		empSet.add(new Employee(1001, "Nazish"));
		empSet.add(new Employee(1002, "Kishan"));
		empSet.add(new Employee(1001, "Nazish"));
		empSet.add(null);
		
		for (Employee employee : empSet) {
			System.out.println(employee);
		}
	}

}
