package WeakHashMapTest;

import java.util.Map;
import java.util.WeakHashMap;

public class WeakHashTest {

	public static void main(String[] args) {

		//Map<String,Integer> map = new HashMap<>();
		Map<String,Integer> map = new WeakHashMap<>();
		
		String key1 = new String("Nazish");
		String key2 = new String("Kishan");
		
		map.put(key1, 1001);
		map.put(key2, 10010);
		
		System.out.println(map);
		
		key1 = null;
		key2 = null;
		System.gc();
		
		System.out.println(map);
	}
}
