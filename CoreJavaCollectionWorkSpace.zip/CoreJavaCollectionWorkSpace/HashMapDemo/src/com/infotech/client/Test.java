package com.infotech.client;

import java.util.ArrayList;
import java.util.List;

import com.infotech.model.Student;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		List<Long> list = new ArrayList<>();
		list.add(1001L);
		list.add(2783L);
		iterateList(list);
		
		System.out.println(new Student(1002, "Ahmad").hashCode());
		System.out.println(new Student(1002, "Ahmad").hashCode());
	}
	
	public static void iterateList(List<? extends Number> list){
		for (Number number : list) {
			System.out.println(number);
		}
	}

}
