package com.infotech.client;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import com.infotech.model.Address;
import com.infotech.model.Student;

public class ClienTest {

	public static void main(String[] args) {
		//mapWithWrapperAndStringObjects();
		mapWithCustomObjects();
	}

	private static void mapWithCustomObjects() {
		Map<Student,Address> stuAddrMap = new LinkedHashMap<>();
		stuAddrMap.put(new Student(1001, "Nazish"), new Address(101, "Pune", 1929029L));
		stuAddrMap.put(new Student(1002, "Ahmad"), new Address(102, "Mumbai", 19200566L));
		
		Set<Entry<Student, Address>> entrySet = stuAddrMap.entrySet();
		System.out.println(entrySet.size());
		for (Entry<Student, Address> entry : entrySet) {
			Student student = entry.getKey();
			System.out.println(student);
			Address address = entry.getValue();
			System.out.println(address);
		}
		
		System.out.println("---------------------------------------");
		Student student = new Student(1002, "Ahmad");
		Address address = stuAddrMap.get(student);
		System.out.println(address);
	}

	private static void mapWithWrapperAndStringObjects() {
		Map<Integer,String> stuNameRollMap = new HashMap<>();
		
		stuNameRollMap.put(1002, "Gaurabh");
		stuNameRollMap.put(1001, "Nazish");
		stuNameRollMap.put(1003, "Raj");
		stuNameRollMap.put(null, "KK");
		stuNameRollMap.put(null, "PK");
		stuNameRollMap.put(1001, "Nazish2");
		
		Set<Integer> roles = stuNameRollMap.keySet();
		Iterator<Integer> iterator = roles.iterator();
		while (iterator.hasNext()) {
			Integer role = iterator.next();
			System.out.println(role+"\t"+stuNameRollMap.get(role));
		}
		System.out.println("---------------------------------------");
		
		Set<Entry<Integer, String>> entrySet = stuNameRollMap.entrySet();
		for (Entry<Integer, String> entry : entrySet) {
			System.out.println(entry.getKey()+"\t"+entry.getValue());
		}
	}
}
