package com.infotech.model;

public class Address {

	private Integer addressId;
	private String city;
	private Long zipCode;
	
	public Address(Integer addressId, String city, Long zipCode) {
		super();
		this.addressId = addressId;
		this.city = city;
		this.zipCode = zipCode;
	}
	public Integer getAddressId() {
		return addressId;
	}
	public String getCity() {
		return city;
	}
	public Long getZipCode() {
		return zipCode;
	}
	@Override
	public String toString() {
		return "Address [addressId=" + addressId + ", city=" + city
				+ ", zipCode=" + zipCode + "]";
	}
	
	
}
