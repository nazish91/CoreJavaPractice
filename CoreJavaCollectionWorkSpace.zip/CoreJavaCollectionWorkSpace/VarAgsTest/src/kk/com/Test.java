package kk.com;

public class Test {

	public static void main(String[] args) {

		nameList("Kishan");
		System.out.println("----------------");
		nameList("Kishan","Nazish");
		System.out.println("----------------");
		nameList();
		System.out.println("----------------");
		nameList2(122,"KK","PK","MK");
		System.out.println("----------------");
		nameList2(1900);
	}

	private static void nameList(String... names){
		
		for (String name : names) {
			System.out.println(name);
		}
	}
	
	private static void nameList2(int data,String... names){
		
		System.out.println(data);
		for (String name : names) {
			System.out.println(name);
		}
	}
	
/*private static void nameList3(String... names,int data){
		
		System.out.println(data);
		for (String name : names) {
			System.out.println(name);
		}
	}*/
}
