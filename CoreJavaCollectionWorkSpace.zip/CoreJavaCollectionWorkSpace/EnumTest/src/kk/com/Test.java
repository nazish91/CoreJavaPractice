package kk.com;

public class Test {

enum Fruits{
		APPLE,MANGo,GRAPES
	}
	public static void main(String[] args) {
		Fruits[] values = Fruits.values();
		
		for (Fruits fruits : values) {
			System.out.println(fruits+"\t"+fruits.ordinal());
		}
		
		UserType[] values2 = UserType.values();
		for (UserType userType : values2) {
			System.out.println(userType);
		}
		
		int arr[]={234,4,45};
		System.out.println(arr);
	}

}
