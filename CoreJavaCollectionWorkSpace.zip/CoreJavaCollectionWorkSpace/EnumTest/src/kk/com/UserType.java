package kk.com;

public enum UserType {
 ADMIN,MANAGER,DEV;
}
