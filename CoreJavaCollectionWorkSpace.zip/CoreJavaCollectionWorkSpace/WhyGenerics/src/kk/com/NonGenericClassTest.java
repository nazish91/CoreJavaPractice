package kk.com;


public class NonGenericClassTest {

	public static void main(String[] args) {
		NonGenericType nonGenericType = new NonGenericType();
		nonGenericType.setObject("Nazish");
		
		Object object = nonGenericType.getObject();
		if(object != null){
			String name = (String)object;
			System.out.println(name);
		}
		nonGenericType = new NonGenericType();
		nonGenericType.setObject(23);
		Object object2 = nonGenericType.getObject();
		if(object2 != null){
			int age=(Integer)object2;
			System.out.println(age);
		}
	}

}

class NonGenericType{
	private Object object;
	
	public Object getObject() {
		return object;
	}
	
	public void setObject(Object object) {
		this.object = object;
	}
}