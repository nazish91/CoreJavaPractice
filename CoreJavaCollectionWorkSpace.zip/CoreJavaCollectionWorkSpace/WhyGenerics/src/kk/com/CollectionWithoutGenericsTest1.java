package kk.com;

import java.util.ArrayList;
import java.util.List;

public class CollectionWithoutGenericsTest1 {

	public static void main(String[] args) {

		List<Employee> list = new ArrayList<>();
		list.add(new Employee(1001, "Kishan"));

		// list.add(255);

		for (Employee employee : list) {
			System.out.println(employee);
		}
	}

}
