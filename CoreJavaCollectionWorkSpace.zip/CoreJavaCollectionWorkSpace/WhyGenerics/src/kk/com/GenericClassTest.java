package kk.com;


public class GenericClassTest {

	public static void main(String[] args) {
		GenericClassType genericClassType = new GenericClassType();
		genericClassType.setObject("Nazish");
		
		System.out.println((String)genericClassType.getObject());
		
		GenericClassType<String> genericClassType2 = new GenericClassType<>();
		genericClassType2.setObject("Kishan");
		
		String name = genericClassType2.getObject();
		GenericClassType<Integer> genericClassType3 = new GenericClassType<>();
		genericClassType3.setObject(90);
		//genericClassType3.setObject("Kishan");
		System.out.println(genericClassType3.getObject());
	}
}

class GenericClassType<T>{
	
	private T object;
	
	public T getObject() {
		return object;
	}
	
	public void setObject(T object) {
		this.object = object;
	}
}