package kk.com;

import java.util.ArrayList;
import java.util.List;

public class GenericsUpperBoundWildCardTest {

	public static void main(String[] args) {

		List<Number> numberList = new ArrayList<>();
		numberList.add(1000);
		numberList.add(90.00);
		sumList(numberList);
		
		List<Integer> intList = new ArrayList<>();
		intList.add(101);
		intList.add(90);
		sumList(intList);
	}

	private static void sumList(List<? extends Number> list) {
		double sum = 0.0d;
		for (Number number : list) {
			sum = sum+number.doubleValue();
		}
		
		System.out.println(sum);
	}
}
