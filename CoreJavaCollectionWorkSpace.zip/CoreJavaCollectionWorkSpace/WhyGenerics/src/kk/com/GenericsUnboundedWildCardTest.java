package kk.com;

import java.util.ArrayList;
import java.util.List;

public class GenericsUnboundedWildCardTest {

	public static void main(String[] args) {

		List<?> list11  = new ArrayList<>();
		List<Object> list1 = new ArrayList<>();
		list11 = list1;
		List<String> strList = new ArrayList<>();
		list11 = strList;
		//list1= strList;
	
		List<Integer> list = new ArrayList<>();
		list.add(1000);
		list.add(8920);
		iterateList(list);
		
		List<String> list101 = new ArrayList<>();
		list101.add("Kishan");
		list101.add("Nazish");
		iterateList(list101);
	}

	private static void iterateList(List<?> list){
		for (Object object : list) {
			if(object instanceof Integer){
				System.out.println((Integer)object);
			}else if(object instanceof String){
				System.out.println((String)object);
			}
		}
	}
}
