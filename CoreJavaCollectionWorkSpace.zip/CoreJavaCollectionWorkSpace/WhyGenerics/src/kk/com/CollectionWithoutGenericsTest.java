package kk.com;

import java.util.ArrayList;
import java.util.List;

public class CollectionWithoutGenericsTest {

	public static void main(String[] args) {
		
		List list = new ArrayList<>();
		list.add(new Integer(100));//Boxing
		list.add(new Integer(200));
		
		list.add(new Float(399.727f));
		
		list.add(new Employee(100, "Nazish"));
		
		for (Object object : list) {
			if(object instanceof Integer){
				Integer id =(Integer)object;
				System.out.println(id);
			}else if(object instanceof Float){
				Float fee =(Float)object;
				System.out.println(fee);
			}else if(object instanceof Employee){
				Employee employee=(Employee)object;
				System.out.println(employee);
			}
		}
		
	}

}
