package kk.com;

import java.util.ArrayList;
import java.util.List;

public class Test {

	@SuppressWarnings("unchecked")
	public static void main(String[] args) {
		@SuppressWarnings("rawtypes")
		List list= new ArrayList();
		list.add("Kishan");
		
		for (Object object : list) {
			System.out.println(object);
		}
		
		EmployeeDAo ao = new EmployeeDAo();
		ao.display();
	}

}
