package kk.com;

public class EmployeeDAo {

	@Deprecated
	public void display(){
		System.out.println("Not in use");
	}
}
