package kk.com;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import com.infotech.model.Address;
import com.infotech.model.Student;

public class TreeMapTest {

	public static void main(String[] args) {

		//Map<Student,Address> stuAddrMap = new TreeMap<Student,Address>();
		Map<Student,Address> stuAddrMap = new TreeMap<>();
		stuAddrMap.put(new Student(1001, "Nazish"), new Address(101, "Pune", 1929029L));
		stuAddrMap.put(new Student(1002, "Ahmad"), new Address(102, "Mumbai", 19200566L));
		//stuAddrMap.put(new Student(1002, "Ahmad"), null);
		
		Set<Entry<Student, Address>> entrySet = stuAddrMap.entrySet();
		System.out.println(entrySet.size());
		for (Entry<Student, Address> entry : entrySet) {
			Student student = entry.getKey();
			System.out.println(student);
			Address address = entry.getValue();
			System.out.println(address);
		}
	}

}
