package com.kk.model;

import java.util.ArrayList;
import java.util.List;

public class GenericsWithLowerBoundTest {

	public static void main(String[] args) {

		List<Employee> empList = new ArrayList<>();
		empList.add(new Employee("kk@gmail.com", "HR", 12233, "KK"));
		iterateList(empList);
		
		System.out.println("----------------------------");
		List<Person> personList = new ArrayList<>();
		personList.add(new Employee("pk@gmail.com", "IT", 128931893, "PK"));
		personList.add(new Person("nazish.cs@gmail.com", "Admin"));
		iterateList(personList);
	}

	private static void iterateList(List<? super Employee> list){
		for (Object object : list) {
			if(object instanceof Employee){
				System.out.println((Employee)object);
			}else if(object instanceof Person){
				System.out.println((Person)object);
			}
		}
	}
}

