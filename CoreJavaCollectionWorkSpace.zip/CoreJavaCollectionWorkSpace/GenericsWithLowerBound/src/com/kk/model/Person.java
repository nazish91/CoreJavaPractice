package com.kk.model;

class Person{
	private String email;
	private String dept;
	public Person(String email, String dept) {
		super();
		this.email = email;
		this.dept = dept;
	}
	@Override
	public String toString() {
		return "Person [email=" + email + ", dept=" + dept + "]";
	}
}