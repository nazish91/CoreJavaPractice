package com.kk.model;

public class HR extends Person {

	private String location;
	private Double salary;
	private String email;
	private String dept;
	public HR(String email, String dept, String location, Double salary,
			String email2, String dept2) {
		super(email, dept);
		this.location = location;
		this.salary = salary;
		email = email2;
		dept = dept2;
	}
	@Override
	public String toString() {
		return "HR [location=" + location + ", salary=" + salary + ", email="
				+ email + ", dept=" + dept + "]";
	}
}
