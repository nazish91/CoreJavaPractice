package com.infotech.client;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.infotech.model.Employee;
import com.infotech.util.DBUtil;
public class ClientTest {

	public static void main(String[] args) throws ClassNotFoundException, SQLException  {
		//insertRowUsingRS();
		//readRowUsingRS();
		updateRowUsingRS();
		
	}

	private static void updateRowUsingRS() {

		Connection connection = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			 connection = DBUtil.getMySqlConnection();
			st = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			 String SQL= "SELECT *FROM employee_table";
			 rs = st.executeQuery(SQL);
			 //Update a row using RS..
			 
			 rs.relative(4);
			 Scanner scanner = new Scanner(System.in);
			 System.out.println("Enter new Email:");
			 String email = scanner.next();
			 
			 rs.updateString("email", email);
			 
			 rs.updateRow();
			 
			 System.out.println("Email is updated..");
			 scanner.close();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DBUtil.CloseDb(rs, st, connection);
		}
	
	}

	private static void readRowUsingRS() {

		Connection connection = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			 connection = DBUtil.getMySqlConnection();
			//st = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
			 st = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
			 String SQL= "SELECT *FROM employee_table";
			 rs = st.executeQuery(SQL);
			 //Read a  row using RS..
			 rs.absolute(1);
			 
			 Employee employee = new Employee();
			 int empId = rs.getInt(1);
			 String eName=rs.getString(2);
			 Double salary = rs.getDouble(3);
			 String email=rs.getString(4);
			 String gender=rs.getString(5);
			 
			 employee.setEmail(email);
			 employee.setEmployeeId(empId);
			 employee.setEmployeeName(eName);
			 employee.setSalary(salary);
			 employee.setGender(gender);
			 
			 System.out.println(employee);
			
			 System.out.println();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DBUtil.CloseDb(rs, st, connection);
		}
	
	}

	private static void insertRowUsingRS() {
		Connection connection = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			 connection = DBUtil.getMySqlConnection();
			st = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE);
			 String SQL= "SELECT *FROM employee_table";
			 rs = st.executeQuery(SQL);
			 //INSERT a new row using RS..
			 
			 rs.moveToInsertRow();
			 Employee employee = getEmployee();
			 rs.updateString("employee_name", employee.getEmployeeName());
			 rs.updateDouble("salary", employee.getSalary());
			 rs.updateString("email", employee.getEmail());
			 rs.updateString("gender", employee.getGender());
			 
			 rs.insertRow();
			 System.out.println("Row is inserted..");
			 
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DBUtil.CloseDb(rs, st, connection);
		}
	}

	private static Employee getEmployee() {
		// TODO Auto-generated method stub
		Employee employee = new Employee();
		employee.setEmail("pk@gmail.com");
		employee.setEmployeeName("PK");
		employee.setGender("Male");
		employee.setSalary(50000.00);
		return employee;
	}
}
