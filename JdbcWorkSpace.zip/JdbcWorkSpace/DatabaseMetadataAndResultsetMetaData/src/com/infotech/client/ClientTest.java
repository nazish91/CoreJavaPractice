package com.infotech.client;

import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import com.infotech.model.Employee;
import com.infotech.util.DBUtil;
public class ClientTest {

	public static void main(String[] args) throws ClassNotFoundException, SQLException  {
		//dataBaseMetaData();
		resultsetMetaData();
	}

	private static void resultsetMetaData() {
		Connection connection = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			 connection = DBUtil.getMySqlConnection();
			 st = connection.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
			 String SQL= "SELECT *FROM employee_table";
			 rs = st.executeQuery(SQL);
			 
			 ResultSetMetaData metaData = rs.getMetaData();
			 System.out.println(metaData.getTableName(1));
			 System.out.println(metaData.getColumnCount());
			 System.out.println(metaData.getColumnClassName(1));
			 
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DBUtil.CloseDb(rs, st, connection);
		}
	}

	private static void dataBaseMetaData() {

		Connection connection = null;
		try {
			 connection = DBUtil.getMySqlConnection();
			 DatabaseMetaData metaData = connection.getMetaData();
			 
			 System.out.println(metaData.getDriverName());
			 System.out.println(metaData.getURL());
			 System.out.println(metaData.getUserName());
		}catch(Exception e){
				e.printStackTrace();
			}
		finally{
			DBUtil.CloseDb(null, null, connection);
		}
	}
}
