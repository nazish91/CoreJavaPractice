package com.infotech.client;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.infotech.model.Employee;
import com.infotech.util.DBUtil;

public class ClienTest {

	public static void main(String[] args) {

		//batchUpdateUsingStatement();
		List<Employee> empList = getEmployeesList();
		batchUpdateUsingPreparedStatement(empList);
	}

	private static List<Employee> getEmployeesList() {
		List<Employee> empList = new ArrayList<>();
		for (int i = 1; i < 6; i++) {
			Employee employee= new Employee();
			employee.setEmail("nazish.ansari_"+i+"gmail.com");
			employee.setEmployeeName("Nazish Ansari_"+i);
			employee.setGender("Male");
			employee.setSalary(20000+i*100d);
			empList.add(employee);
		}
		return empList;
	}

	private static void batchUpdateUsingPreparedStatement(List<Employee> empList) {

		Connection connection = DBUtil.getMySqlConnection();
		PreparedStatement ps = null;
		
		try {
			ps = connection.prepareStatement("INSERT INTO employee_table(employee_name,salary,email,gender)VALUES(?,?,?,?)");
			for (Employee employee : empList) {
				ps.setString(1, employee.getEmployeeName());
				ps.setDouble(2, employee.getSalary());
				ps.setString(3, employee.getEmail());
				ps.setString(4, employee.getGender());
				
				ps.addBatch();
			}
			
			int[] executeBatch = ps.executeBatch();
			for (int i : executeBatch) {
				System.out.println(i);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DBUtil.CloseDb(null, ps, connection);
		}
	
	}

	private static void batchUpdateUsingStatement() {

		Connection connection = DBUtil.getMySqlConnection();
		Statement statement = null;
		
		try {
			statement = connection.createStatement();
			
			String INSERT_SQL1 = "INSERT INTO employee_table(employee_name,salary,email,gender)VALUES('Ram',40000,'ram.cs2016@gmail.com','Male')";
			String INSERT_SQL2 = "INSERT INTO employee_table(employee_name,salary,email,gender)VALUES('Nasim',60000,'nasim.cs2019@gmail.com','Male')";
			String UPDATE_SQL = "UPDATE employee_table set email='kishan.cs2006@gmail.com' WHERE employee_id = 9";
			String DELETE_SQL1 = "DELETE FROM employee_table  WHERE employee_id=12";
			String DELETE_SQL2 = "DELETE FROM employee_table  WHERE employee_id=120";
			
			statement.addBatch(INSERT_SQL1);
			statement.addBatch(INSERT_SQL2);
			statement.addBatch(UPDATE_SQL);
			statement.addBatch(DELETE_SQL1);
			statement.addBatch(DELETE_SQL2);
			
			int[] executeBatch = statement.executeBatch();
			for (int i : executeBatch) {
				System.out.println(i);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DBUtil.CloseDb(null, statement, connection);
		}
	}
}
