package com.infotech.client;

import com.infotech.Hello;


public class Test {

	
	public static void main(String[] args)  {
		
		Class cls=null;
		try {
			 cls = Class.forName("com.infotech.Hello");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try {
		Hello hello	=(Hello)cls.newInstance();
		hello.display();
		
			
		} catch (InstantiationException | IllegalAccessException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
	
}
}