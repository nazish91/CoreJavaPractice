package com.infotech;

public class Hello {
	
	
	static{
		System.out.println("in Static block...");
		
	}
	
	public Hello()
	{
		System.out.println("In default constructor of class");
	}
	
	public void display()
	{
		System.out.println("Display method");
		
	}
}
