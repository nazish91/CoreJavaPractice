package com.infotech.client;

import java.sql.SQLException;

import com.infotech.daoimpl.EmployeeDAO;
import com.infotech.daoimpl.EmployeeDaoImpl;
//CRUD
public class ClientTest {

	public static void main(String[] args) throws ClassNotFoundException, SQLException  {
		EmployeeDAO employeeDaoImpl = new EmployeeDaoImpl();	
		//createEmployee(employeeDaoImpl);
		employeeDaoImpl.createEmployee();
		//employeeDaoImpl.updateEmailByEmployeeId();
		//employeeDaoImpl.deleteEmployeeById();
		//employeeDaoImpl.getEmployeeById();
		//employeeDaoImpl.allEmployeesInfo();
	}

	private static void createEmployee(EmployeeDAO employeeDaoImpl) {
		try {
			employeeDaoImpl.createEmployee();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

}
