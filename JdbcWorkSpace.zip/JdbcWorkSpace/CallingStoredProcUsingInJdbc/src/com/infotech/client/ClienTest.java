package com.infotech.client;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Types;
import java.util.Scanner;

import com.infotech.util.DBUtil;

public class ClienTest {

	public static void main(String[] args) {

		Connection connection = DBUtil.getMySqlConnection();
		CallableStatement cs = null;
		Scanner scanner = null;
		try {
			String sql = "{CALL getEmployeeDetailsById(?,?,?)}";
			cs = connection.prepareCall(sql);
			
			scanner = new Scanner(System.in);
			System.out.println("Enter Employee ID:");
			int employeeId = scanner.nextInt();
			
			cs.setInt("empId", employeeId);
			
			cs.registerOutParameter("empname", Types.VARCHAR);
			cs.registerOutParameter("esalary", Types.DOUBLE);
			
			cs.execute();
			
			System.out.println("Employee Name:"+cs.getString("empname"));
			System.out.println("Salary:"+cs.getDouble("esalary"));
			
		} catch (Exception e) {
			e.printStackTrace();
			
		}finally{
			DBUtil.CloseDb(null, cs, connection);
		}
	}
}
