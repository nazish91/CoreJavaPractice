package com.infotech.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBUtil {

	private static final String DB_USERNAME = "root";
	private static final String DB_PASSWORD = "nazish";
	private static final String DB_URL = "jdbc:mysql://localhost:3306/jdbcdb";
	private static final String DRIVER_CLASS = "com.mysql.jdbc.Driver";
	private static Connection conn = null;
	static {
		// 1.Register JDBC driver
		try {
			try {
				Class.forName(DRIVER_CLASS);
			} catch (ClassNotFoundException e) {
				e.printStackTrace();
			}
			// 2.Getting connection using DriverMananger.
			conn = DriverManager
					.getConnection(DB_URL, DB_USERNAME, DB_PASSWORD);
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public static Connection getMySqlConnection() {
		return conn;
	}

	public static void CloseDb(ResultSet rs, Statement st, Connection conn) {
		if(rs != null){
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		if(st != null){
			try {
				st.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		if(conn != null){
			try {
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

	}
}
