CREATE PROCEDURE getEmployeeDetailsById (IN empId INT,OUT empname VARCHAR(50),OUT esalary DOUBLE)
BEGIN
	SELECT employee_name,salary INTO empname, esalary FROM employee_table WHERE employee_id=empId;
END;


-----------------------------------------------------------------------------
CALL getEmployeeDetailsById(10, @empname, @esalary);
SELECT @empname, @esalary;