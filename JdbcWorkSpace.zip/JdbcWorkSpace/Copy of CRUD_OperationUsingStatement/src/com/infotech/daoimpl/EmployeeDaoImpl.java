package com.infotech.daoimpl;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.infotech.util.DBUtil;

public class EmployeeDaoImpl implements EmployeeDAO {

	/* (non-Javadoc)
	 * @see com.infotech.daoimpl.EmployeeDAO#createEmployee()
	 */
	public void createEmployee() throws SQLException {
		Connection conn = null;
		Statement st = null;
		try {
			conn = DBUtil.getConnection();
			//3.Creating JDBC statement
			st = conn.createStatement();
			
			//4.Prepare SQL query..
			String SQL = "INSERT INTO employee_table(employee_name,salary,email,gender)VALUES('aloo',90000,'aloo.cs2016@gmail.com','Male')";
			
			//5.Execute SQL query
			int executeUpdate = st.executeUpdate(SQL);
			//6.process the result
			if(executeUpdate>0){
				System.out.println("Employee is created...");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DBUtil.CloseDb(null,st,conn);
		}
	}

	public void updateEmailByEmployeeId() {
		Connection conn = null;
		Statement st = null;
		try {
			conn = DBUtil.getConnection();
			//3.Creating JDBC statement
			st = conn.createStatement();
			
			//4.Prepare SQL query..
			String SQL = "UPDATE employee_table set email='kk2016@gmail.com' WHERE employee_id=7";
			
			//5.Execute SQL query
			int executeUpdate = st.executeUpdate(SQL);
			//6.process the result
			if(executeUpdate>0){
				System.out.println("Email is updated.....");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DBUtil.CloseDb(null,st,conn);
		}
	}

	public void deleteEmployeeById() {

		Connection conn = null;
		Statement st = null;
		try {
			conn = DBUtil.getConnection();
			//3.Creating JDBC statement
			st = conn.createStatement();
			
			//4.Prepare SQL query..
			String SQL = "DELETE FROM employee_table  WHERE employee_id=7";
			
			//5.Execute SQL query
			int executeUpdate = st.executeUpdate(SQL);
			//6.process the result
			if(executeUpdate>0){
				System.out.println("Employee is deleted.....");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DBUtil.CloseDb(null,st,conn);
		}
	}

	public void getEmployeeById() {

		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnection();
			//3.Creating JDBC statement
			st = conn.createStatement();
			
			//4.Prepare SQL query..
			String SQL = "SELECT *FROM employee_table  WHERE employee_id=8";
			
			//5.Execute SQL query
			 rs = st.executeQuery(SQL);
			 if(rs.next()){
				 int empId = rs.getInt(1);
				 String eName=rs.getString(2);
				 Double salary = rs.getDouble(3);
				 String email=rs.getString(4);
				 String gender=rs.getString(5);
				 
				 System.out.println(empId+"\t"+eName+"\t"+salary+"\t"+email+"\t"+gender);
				 
				 
			 }
			//6.process the result
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DBUtil.CloseDb(rs,st,conn);
		}
	}

	public void allEmployeesInfo() {

		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		try {
			conn = DBUtil.getConnection();
			//3.Creating JDBC statement
			st = conn.createStatement();
			
			//4.Prepare SQL query..
			String SQL = "SELECT *FROM employee_table";
			
			//5.Execute SQL query
			 rs = st.executeQuery(SQL);
			 while(rs.next()){
				 int empId = rs.getInt(1);
				 String eName=rs.getString(2);
				 Double salary = rs.getDouble(3);
				 String email=rs.getString(4);
				 String gender=rs.getString(5);
				 
				 System.out.println(empId+"\t"+eName+"\t"+salary+"\t"+email+"\t"+gender);
				 
				 
			 }
			//6.process the result
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DBUtil.CloseDb(rs,st,conn);
		}
	
	}
}
