package com.infotech.daoimpl;

import java.sql.SQLException;

public interface EmployeeDAO {

	public abstract void createEmployee() throws SQLException;
	public abstract void updateEmailByEmployeeId();
	public abstract void deleteEmployeeById();
	public abstract void getEmployeeById();
	public abstract void allEmployeesInfo();

}