package com.infotech.util;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



public class DBUtil {
private static String usrname ="root";
private static String pasword= "nazish";
private static String driver = "com.mysql.jdbc.Driver";
private static final String DB_URL = "jdbc:mysql://localhost:3306/jdbcdb";
private static Connection cn= null;

static 
{
	try {
		Class.forName(driver);
	} catch (ClassNotFoundException e) {
		e.printStackTrace();
	}
	
	try {
		cn= DriverManager.getConnection(DB_URL, usrname, pasword);
	} catch (SQLException e) {
		e.printStackTrace();
	}
	
	
}

public static Connection getConnection()
{
	return cn;
	
}

public static void CloseDb(ResultSet rs,Statement st,Connection cn)
{
	
	if(rs!=null)
	{
		try {
			rs.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	if(st!=null)
	{
		try {
			st.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	if(cn!=null)
	{
	try {
		cn.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}	
	}
	
	
}

	
	
}
