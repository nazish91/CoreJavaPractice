CREATE TABLE `icici_account` (
  `account_no` bigint(20) NOT NULL,
  `account_balance` bigint(20) DEFAULT NULL,
  `account_type` varchar(20) NOT NULL,
  `account_holder_name` varchar(40) DEFAULT NULL
) ;

