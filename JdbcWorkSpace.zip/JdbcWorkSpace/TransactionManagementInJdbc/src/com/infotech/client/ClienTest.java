package com.infotech.client;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import com.infotech.model.Account;
import com.infotech.util.DBUtil;

public class ClienTest {

	public static void main(String[] args) {

		Connection connection = DBUtil.getMySqlConnection();
		PreparedStatement ps = null;
		
		try {
			Account fromAccount = new Account();
			fromAccount.setAccountNumber(9887378378L);
			Account toAccount = new Account();
			toAccount.setAccountNumber(9887378300L);
			Long amount = 1000L;
			
			connection.setAutoCommit(false);//Transaction Management starts here
			withdraw(connection,fromAccount,toAccount,amount);
			deposit(connection,fromAccount,toAccount,amount);
			
			connection.commit();//Transaction Management end here
		} catch (Exception e) {
			e.printStackTrace();
			if(connection != null){
				try {
					connection.rollback();//Transaction Management end here
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
			}
		}finally{
			DBUtil.CloseDb(null, ps, connection);
		}
	}

	private static void deposit(Connection connection, Account fromAccount,
			Account toAccount, Long amount) throws SQLException {
		
		Statement st = connection.createStatement();
		int executeUpdate = st.executeUpdate("UPDATE icici_account set account_balance1=account_balance+"+amount+" WHERE account_no="+toAccount.getAccountNumber());
		if(executeUpdate>0){
			System.out.println("Amount Rs:"+amount+" is deposited in Account:"+toAccount.getAccountNumber());
		}
	}

	private static void withdraw(Connection connection, Account fromAccount,
			Account toAccount, Long amount) throws SQLException {
		
		Statement st = connection.createStatement();
		int executeUpdate = st.executeUpdate("UPDATE icici_account set account_balance=account_balance-"+amount+" WHERE account_no="+fromAccount.getAccountNumber());
		if(executeUpdate>0){
			System.out.println("Amount Rs:"+amount+" is transferred from Account:"+fromAccount.getAccountNumber()+" to Account:"+toAccount.getAccountNumber());
		}
	
		
	}

}
