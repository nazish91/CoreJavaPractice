import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;

public class Test {
	//Student student1= new Student();
	ArrayList<Student> st = new ArrayList<Student>();
	ArrayList<Student> duparr = new ArrayList<Student>();
	HashMap<String, ArrayList<Student>> arst= new HashMap<>();
	@SuppressWarnings("resource")
	public  void abc(){
	try {
		File f = new File("C:\\Users\\FAIZAN\\Desktop\\abc.txt");
        BufferedReader in = new BufferedReader(new FileReader("C:\\Users\\FAIZAN\\Desktop\\abc.txt"));
        String str;
        
        
        if (f.exists()) {
			System.out.println("valid");
		}
        else
        {
        	System.out.println("invalid");
        }
        
        
        while ((str = in.readLine())!= null) {
        	Student student1= new Student();	
            String[] ar=str.split(",");
            String string = Arrays.toString(ar);
            String[] split = string.split(",");
           
            student1.setS1(split[0]);
            student1.setS2(split[1]);
            student1.setS3(split[2]);
            student1.setS4(split[3]);
            student1.setS5(split[4]);
            student1.setS6(split[5]);
            st.add(student1);
            //System.out.println(st);
            
            
				/*String s1 = split[0];
				String s2 = split[1];
				String s3 = split[2];
				String s4 = split[3];
				String s5 = split[4];
				String s6 = split[5];
            	//System.out.println(split[i]);
				System.out.println(s1);
				System.out.println(s2);
				System.out.println(s3);
				System.out.println(s4);
				System.out.println(s5);
				System.out.println(s6);*/
				
				
			
            //String string2 = (split[0]);
            //System.out.println(split[0]);
            //System.out.println(string2);
        }
        in.close();
    } catch (IOException e) {
        System.out.println("File Read Error");
    }
	}
	
	HashSet<String> set = new HashSet<>();
	ArrayList<String> arry = new ArrayList<>();
	ArrayList<String> arry1 = new ArrayList<>();
	
	public void def(){
	for (Student student : st) {
		//System.out.println(student.getS2()+"\t"+student.getS1()+"\t"+student.getS3()+"\t"+student.getS4()+"\t"+student.getS5()+"\t"+student.getS6());
		//System.out.println((st));
		
		String[] split = student.getS1().split("-");
		
		//System.out.println(split[1].contains("1234"));
		
				arry.add(split[1]);
				System.out.println(arry);
				}
	for (String abc : arry ) {
		if (set.add(abc) == false) { // your duplicate element }
			arry1.add(abc);
			
		System.out.println("policy num "+abc+" is duplicate");
		}
	}
	
for (Student string : st) {
	
	for (String dup : arry1) {
		
		if (string.getS1().contains(dup)) {
			System.out.println("win");
			System.out.println(string);
			duparr.add(string);	
			
		}
		
	}
	
	arst.put("DUP", duparr);
	System.out.println(arst);
	
}

	/*for (int i = 0; i < st.size(); i++) {
		System.out.println(st.get(i));
		if ((st.get(0).getS3()).contains("sad")) {
			System.out.println("true");
		}
		else
		{
			System.out.println("false");
		}
		String s1 = st.get(0).getS1();
		if (s1.startsWith("28", 1)) {
			System.out.println("true2");
		}
		
		
	}*/
	
	
	
	
	
	}
	
	
	
	
 
	
	
	
	class Student
	{
		String s1;
		String s2;
		String s3;
		String s4;
		String s5;
		String s6;
		public String getS1() {
			return s1;
		}
		public void setS1(String s1) {
			this.s1 = s1;
		}
		public String getS2() {
			return s2;
		}
		public void setS2(String s2) {
			this.s2 = s2;
		}
		public String getS3() {
			return s3;
		}
		public void setS3(String s3) {
			this.s3 = s3;
		}
		public String getS4() {
			return s4;
		}
		public void setS4(String s4) {
			this.s4 = s4;
		}
		public String getS5() {
			return s5;
		}
		public void setS5(String s5) {
			this.s5 = s5;
		}
		public String getS6() {
			return s6;
		}
		public void setS6(String s6) {
			this.s6 = s6;
		}
		@Override
		public String toString() {
			return "Student [s1=" + s1 + ", s2=" + s2 + ", s3=" + s3 + ", s4=" + s4 + ", s5=" + s5 + ", s6=" + s6 + "]";
		}
		
		
		
		
	}
	
	
	public static void main(String[] args) {
		Test t = new Test();
		t.abc();
		t.def();
	}
	 }

