package com.infotech;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TestClass {
	private static Connection conn=null;
	
	static{
		
		try {
		
		Class cls = Class.forName("com.mysql.jdbc.Driver");
		
		}
		catch (ClassNotFoundException e) {

		System.out.println("Driver not found");
		
		}
		try {
			 conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbcdb", "root", "nazish");
		} catch (SQLException e) {
			e.printStackTrace();

		}
		
		
		
	}
	
	public static Connection getConnection()
	{
		
		System.out.println("connection is created");
		return conn;
		
	}
	
	public static void closeDb(ResultSet rs , Statement st, Connection conn)
	{
		try{
			if (rs!=null) {
				rs.close();
				}
		}
		catch (SQLException e) {
            e.printStackTrace();
			}
		
		
		try{
			if (st!=null) {
				st.close();
				}
		}
		catch (SQLException e) {
            e.printStackTrace();
			}
		
		
		try{
			if (conn!=null) {
				conn.close();
				}
		}
		catch (SQLException e) {
            e.printStackTrace();
			}
		
		}
		
		
	
	
	public static void main(String[] args) {
			
		getConnection();
		closeDb(null, null, conn);
	}

}
