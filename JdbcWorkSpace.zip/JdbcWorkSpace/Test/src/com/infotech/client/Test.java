package com.infotech.client;

import com.infotech.Hello;

public class Test {

	/**
	 * @param args
	 * @throws ClassNotFoundException 
	 * @throws IllegalAccessException 
	 * @throws InstantiationException 
	 */
	public static void main(String[] args) throws ClassNotFoundException, InstantiationException, IllegalAccessException {
		
/*		//Object object = new Hello();
		System.out.println(object);
		Hello h1 =(Hello)object;
*/
//jvm loads the class only when it is required for example if we create the object 
// of Hello class then it will load the Hello class in memory in another scenario
//forName method loads the class at runtime and executes all its static blocks as 
//executed when class is loaded normally at class loading time 
		
		//Hello hello2 = new Hello();
		
		Class cls = Class.forName("com.infotech.Hello");
		
		Hello hello =(Hello) cls.newInstance();
		hello.display();

	}

}
