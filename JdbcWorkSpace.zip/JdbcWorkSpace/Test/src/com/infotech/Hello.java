package com.infotech;

public class Hello {
	
	public  Hello() {
	}

/*	public Hello() {
		System.out.println("Default Constructor..");
	}
*/	public  void display(){
		System.out.println("Hello..");
	}
	
	static{
		System.out.println("Static block..");
	}
}
