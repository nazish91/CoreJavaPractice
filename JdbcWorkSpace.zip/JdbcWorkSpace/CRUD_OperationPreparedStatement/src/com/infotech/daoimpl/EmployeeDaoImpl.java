package com.infotech.daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.infotech.model.Employee;
import com.infotech.util.DBUtil;

public class EmployeeDaoImpl implements EmployeeDAO {

	/* (non-Javadoc)
	 * @see com.infotech.daoimpl.EmployeeDAO#createEmployee()
	 */
	public void createEmployee(Employee employee) throws SQLException {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = DBUtil.getMySqlConnection();
			//3.Creating JDBC statement
			
			//4.Prepare SQL query..
			String SQL = "INSERT INTO employee_table(employee_name,salary,email,gender)VALUES(?,?,?,?)";
			ps= conn.prepareStatement(SQL);
			
			ps.setString(1, employee.getEmployeeName());
			ps.setDouble(2, employee.getSalary());
			ps.setString(3, employee.getEmail());
			ps.setString(4, employee.getGender());
			
			//5.Execute SQL query
			int executeUpdate = ps.executeUpdate();
			//6.process the result
			if(executeUpdate>0){
				System.out.println("Employee is created...");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DBUtil.CloseDb(null,ps,conn);
		}
	}

	public void updateEmailByEmployeeId(String newEmail,int employeeId) {
		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = DBUtil.getMySqlConnection();
			//3.Creating JDBC statement
			//4.Prepare SQL query..
			String SQL = "UPDATE employee_table set email=? WHERE employee_id=?";
	
			ps=conn.prepareStatement(SQL);
			ps.setString(1, newEmail);
			ps.setInt(2, employeeId);
			
			//5.Execute SQL query
			int executeUpdate = ps.executeUpdate();
			//6.process the result
			if(executeUpdate>0){
				System.out.println("Email is updated.....");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DBUtil.CloseDb(null,ps,conn);
		}
	}

	public void deleteEmployeeById(int empId) {

		Connection conn = null;
		PreparedStatement ps = null;
		try {
			conn = DBUtil.getMySqlConnection();
			//3.Creating JDBC statement
			
			
			//4.Prepare SQL query..
			String SQL = "DELETE FROM employee_table  WHERE employee_id=?";
			
			ps = conn.prepareStatement(SQL);
			ps.setInt(1, empId);
			//5.Execute SQL query
			int executeUpdate = ps.executeUpdate();
			//6.process the result
			if(executeUpdate>0){
				System.out.println("Employee is deleted.....");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DBUtil.CloseDb(null,ps,conn);
		}
	}

	public Employee getEmployeeById(int employeeId) {

		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		Employee employee = null;
		try {
			conn = DBUtil.getMySqlConnection();
			
			//4.Prepare SQL query..
			String SQL = "SELECT *FROM employee_table  WHERE employee_id=?";

			//3.Creating JDBC statement
			ps = conn.prepareStatement(SQL);
			ps.setInt(1, employeeId);
			
			//5.Execute SQL query
			 rs = ps.executeQuery();
			 if(rs.next()){

				 employee = new Employee();
				 int empId = rs.getInt(1);
				 String eName=rs.getString(2);
				 Double salary = rs.getDouble(3);
				 String email=rs.getString(4);
				 String gender=rs.getString(5);
				 
				 employee.setEmail(email);
				 employee.setEmployeeId(empId);
				 employee.setEmployeeName(eName);
				 employee.setSalary(salary);
				 employee.setGender(gender);
				 
			 }
			//6.process the result
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DBUtil.CloseDb(rs,ps,conn);
		}
		return employee;
	}

	public List<Employee> allEmployeesInfo() {

		Connection conn = null;
		Statement st = null;
		ResultSet rs = null;
		List<Employee> empList = new ArrayList<>();
		try {
			conn = DBUtil.getMySqlConnection();
			//3.Creating JDBC statement
			st = conn.createStatement();
			
			//4.Prepare SQL query..
			String SQL = "SELECT *FROM employee_table";
			
			//5.Execute SQL query
			 rs = st.executeQuery(SQL);
			 while(rs.next()){	
				 
			 Employee employee = new Employee();
			 int empId = rs.getInt(1);
			 String eName=rs.getString(2);
			 Double salary = rs.getDouble(3);
			 String email=rs.getString(4);
			 String gender=rs.getString(5);
			 
			 employee.setEmail(email);
			 employee.setEmployeeId(empId);
			 employee.setEmployeeName(eName);
			 employee.setSalary(salary);
			 employee.setGender(gender);
			 
			 empList.add(employee);
		
			 }
			//6.process the result
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			DBUtil.CloseDb(rs,st,conn);
		}
		return empList;
	
	}
}
