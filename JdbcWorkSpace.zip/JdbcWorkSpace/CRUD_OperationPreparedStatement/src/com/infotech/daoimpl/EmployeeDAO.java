package com.infotech.daoimpl;

import java.sql.SQLException;
import java.util.List;

import com.infotech.model.Employee;

public interface EmployeeDAO {

	public abstract void createEmployee(Employee employee) throws SQLException;
	public abstract void updateEmailByEmployeeId(String newEmail,int employeeId);
	public abstract void deleteEmployeeById(int empId);
	public abstract Employee getEmployeeById(int employeeId);
	public abstract List<Employee> allEmployeesInfo();

}