package com.infotech.client;

import java.sql.SQLException;
import java.util.List;

import com.infotech.daoimpl.EmployeeDAO;
import com.infotech.daoimpl.EmployeeDaoImpl;
import com.infotech.model.Employee;
//CRUD
public class ClientTest {

	public static void main(String[] args) throws ClassNotFoundException, SQLException  {
		EmployeeDAO employeeDaoImpl = new EmployeeDaoImpl();	
		//createEmployee(employeeDaoImpl);
		//employeeDaoImpl.updateEmailByEmployeeId("pk2016@gmail.com",11);
		//employeeDaoImpl.deleteEmployeeById(11);
		//getEmployeeById(employeeDaoImpl);
		getAllEmployeesInfo(employeeDaoImpl);
	}

	private static void getAllEmployeesInfo(EmployeeDAO employeeDaoImpl) {
		List<Employee> empList = employeeDaoImpl.allEmployeesInfo();
		for (Employee employee : empList) {
			System.out.println(employee);
		}
	}

	private static void getEmployeeById(EmployeeDAO employeeDaoImpl) {
		Employee employee = employeeDaoImpl.getEmployeeById(10);
		if(employee != null)
			System.out.println(employee);
	}

	private static void createEmployee(EmployeeDAO employeeDaoImpl) {
		try {
			Employee employee = getEmployee();
			employeeDaoImpl.createEmployee(employee);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	private static Employee getEmployee() {
		// TODO Auto-generated method stub
		Employee employee = new Employee();
		employee.setEmail("pk@gmail.com");
		employee.setEmployeeName("PK");
		employee.setGender("Male");
		employee.setSalary(50000.00);
		return employee;
	}

}
