package com.infotech.model;

public class PanCard {

	private Integer panId;
	private String panNO;
	
	public Integer getPanId() {
		return panId;
	}
	public void setPanId(Integer panId) {
		this.panId = panId;
	}
	public String getPanNO() {
		return panNO;
	}
	public void setPanNO(String panNO) {
		this.panNO = panNO;
	}
	
	
	
}
