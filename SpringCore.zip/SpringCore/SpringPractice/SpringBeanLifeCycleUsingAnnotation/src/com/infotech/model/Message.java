package com.infotech.model;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;


public class Message{

	private Integer messageId;
	private String message;

	public Integer getMessageId() {
		return messageId;
	}
	public void setMessageId(Integer messageId) {
		this.messageId = messageId;
	}
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	@PostConstruct
	public void init() throws Exception {
		System.out.println("Bean is going through init process..");
	}
	@PreDestroy
	public void destroy() throws Exception {
		System.out.println("Bean is going to destroy..");
	}
}
