package com.infotech.client;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

import com.infotech.model.Message;

public class ClientTest {

	public static void main(String[] args) {
		//getBeanFactory();
		
		//getApplicationContext1();
		getApplicationContext2() ;
		
	}

	private static void getApplicationContext2() {
		
		ApplicationContext context = new FileSystemXmlApplicationContext("src/Beans.xml");
		//ApplicationContext context = new FileSystemXmlApplicationContext("D:\\SpringPractice\\SpringApplicationContextDemo\\src\\Beans.xml");
		
		
		Message message = context.getBean("message", Message.class);
		System.out.println(message.getMessageId()+"\t"+message.getMessage());
	}
	private static void getApplicationContext1() {
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		Message message = context.getBean("message", Message.class);
		System.out.println(message.getMessageId()+"\t"+message.getMessage());
	}

	private static void getBeanFactory() {
		ClassPathResource abc = new ClassPathResource("Beans.xml");
		//BeanFactory factory = new XmlBeanFactory(new ClassPathResource("Beans.xml"));
		BeanFactory factory = new XmlBeanFactory(abc);
		
		Message message = factory.getBean("message", Message.class);
		System.out.println(message.getMessageId()+"\t"+message.getMessage());
	}

}
