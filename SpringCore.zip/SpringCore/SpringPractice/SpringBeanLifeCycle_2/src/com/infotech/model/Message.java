package com.infotech.model;


public class Message{

	private Integer messageId;
	private String message;

	public Integer getMessageId() {
		return messageId;
	}
	public void setMessageId(Integer messageId) {
		this.messageId = messageId;
	}
	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	public void init() throws Exception {
		System.out.println("Bean is going through init process..");
	}
	public void destroy() throws Exception {
		System.out.println("Bean is going to destroy..");
	}
}
