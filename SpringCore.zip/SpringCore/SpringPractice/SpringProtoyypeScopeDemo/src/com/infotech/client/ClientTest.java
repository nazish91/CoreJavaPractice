package com.infotech.client;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.infotech.model.Message;

public class ClientTest {

	public static void main(String[] args) {

		AbstractApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		
		Message message1 = context.getBean("message", Message.class);
		
		message1.setMessage("Hello World!!!");
		message1.setMessageId(10001);
		
		System.out.println(message1.getMessageId()+"\t"+message1.getMessage());
		
		System.out.println("::::::::::::::::::::::::::::::::::::");
		Message message2 = context.getBean("message", Message.class);
		
		System.out.println(message2.getMessageId()+"\t"+message2.getMessage());
		context.close();
	
	}
}
