
public class Ram extends Shyam {

	int a;
	int b;
	
	public Ram(int a,int b){
		
		this.a=a;
		this.b=b;
		
	}

	public static void main(String[] args) {
	

		
		Shyam c = new Ram(11, 55);
		System.out.println(c.a+" "+c.b);
	}

}
