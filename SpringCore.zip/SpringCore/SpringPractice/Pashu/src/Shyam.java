
public class Shyam {

	
	int a=16;
	int b=77;
	
	
}
