package com.infotech.info;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import com.infotech.model.Address;
import com.infotech.model.Student;

public class CollectionInfo {
	
	private List<String> studentNameList;
	private Set<String> cityNames;
	private Set<Student> studentsSet;
	private Map<Integer,String> stuIdAndNameMap;
	private Map<Student,Address> stuAndAddrMap;
	private Properties empIdAndNameProps;
	private Student stuArr[] = new Student[2];
	
	public List<String> getStudentNameList() {
		return studentNameList;
	}
	public void setStudentNameList(List<String> studentNameList) {
		this.studentNameList = studentNameList;
	}
	public Set<String> getCityNames() {
		return cityNames;
	}
	public void setCityNames(Set<String> cityNames) {
		this.cityNames = cityNames;
	}
	public Set<Student> getStudentsSet() {
		return studentsSet;
	}
	public void setStudentsSet(Set<Student> studentsSet) {
		this.studentsSet = studentsSet;
	}
	public Map<Integer, String> getStuIdAndNameMap() {
		return stuIdAndNameMap;
	}
	public void setStuIdAndNameMap(Map<Integer, String> stuIdAndNameMap) {
		this.stuIdAndNameMap = stuIdAndNameMap;
	}
	public Map<Student, Address> getStuAndAddrMap() {
		return stuAndAddrMap;
	}
	public void setStuAndAddrMap(Map<Student, Address> stuAndAddrMap) {
		this.stuAndAddrMap = stuAndAddrMap;
	}
	public Properties getEmpIdAndNameProps() {
		return empIdAndNameProps;
	}
	public void setEmpIdAndNameProps(Properties empIdAndNameProps) {
		this.empIdAndNameProps = empIdAndNameProps;
	}
	public Student[] getStuArr() {
		return stuArr;
	}
	public void setStuArr(Student[] stuArr) {
		this.stuArr = stuArr;
	}
}
