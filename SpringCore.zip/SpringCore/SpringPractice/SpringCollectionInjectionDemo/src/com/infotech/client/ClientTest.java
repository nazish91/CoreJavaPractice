package com.infotech.client;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.infotech.info.CollectionInfo;
import com.infotech.model.Address;
import com.infotech.model.Student;

public class ClientTest {

	public static void main(String[] args) {
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		
		CollectionInfo collectionInfo = context.getBean("collectionInfo", CollectionInfo.class);
		
		List<String> studentNameList = collectionInfo.getStudentNameList();
		System.out.println("studentNameList:::::::::::::::::::");
		for (String name : studentNameList) {
			System.out.println(name);
		}
		
		Set<String> cityNames = collectionInfo.getCityNames();
		System.out.println("cityNames:::::::::::::::::::");
		for (String city : cityNames) {
			System.out.println(city);
		}
		
		Set<Student> studentsSet = collectionInfo.getStudentsSet();
		System.out.println("studentsSet:::::::::::::::::::");
		for (Student student : studentsSet) {
			System.out.println(student.getStudentId()+"\t"+student.getStudentName()+"\t"+student.getPhone());
		}
		
		Map<Integer, String> stuIdAndNameMap = collectionInfo.getStuIdAndNameMap();
		System.out.println("stuIdAndNameMap:::::::::::::::::::");
		Set<Integer> keySet = stuIdAndNameMap.keySet();
		for (Integer studentId : keySet) {
			String sName = stuIdAndNameMap.get(studentId);
			
			System.out.println(studentId+"\t"+sName);
		}
		
		Map<Student, Address> stuAndAddrMap = collectionInfo.getStuAndAddrMap();
		System.out.println("stuAndAddrMap:::::::::::::::::::");
		Set<Entry<Student, Address>> entrySet = stuAndAddrMap.entrySet();
		for (Entry<Student, Address> entry : entrySet) {
			Student student = entry.getKey();
			System.out.println(student.getStudentId()+"\t"+student.getStudentName()+"\t"+student.getPhone());
			Address address = entry.getValue();
			System.out.println(address.getAddressId()+"\t"+address.getCity()+"\t"+address.getStreet()+"\t"+address.getZipCode());
		}
		
		Student[] stuArr = collectionInfo.getStuArr();
		System.out.println("stuArr:::::::::::::::::::");
		for (Student student : stuArr) {
			System.out.println(student.getStudentId()+"\t"+student.getStudentName()+"\t"+student.getPhone());
		}
		context.close();
	}

}
