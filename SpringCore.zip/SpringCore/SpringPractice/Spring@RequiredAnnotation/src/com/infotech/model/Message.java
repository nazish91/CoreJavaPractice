package com.infotech.model;

import org.springframework.beans.factory.annotation.Required;


public class Message {

	private Integer messageId;
	private String message;

	public Integer getMessageId() {
		return messageId;
	}
	public void setMessageId(Integer messageId) {
		this.messageId = messageId;
	}
	public String getMessage() {
		return message;
	}

	@Required
	public void setMessage(String message) {
		this.message = message;
	}
}
