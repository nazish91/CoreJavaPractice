package com.infotech.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.infotech.model.Message;

public class ClientTest {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		Message message = context.getBean("message", Message.class);
		System.out.println(message.getMessageId()+"\t"+message.getMessage());

	}
}
