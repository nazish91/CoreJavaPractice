package com.infotech.client;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.infotech.model.Message;
import com.infotech.model.Temp;

public class ClientTest {

	public static void main(String[] args) {

		AbstractApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		
		Message message1 = context.getBean("message", Message.class);
		Temp temp = message1.getTemp();
		System.out.println(message1.getMessageId()+"\t"+message1.getMessage());
		System.out.println("=====================================");
		System.out.println(temp.getMessage()+""+temp.getMessageId());
		
		context.close();
	
	}
}
