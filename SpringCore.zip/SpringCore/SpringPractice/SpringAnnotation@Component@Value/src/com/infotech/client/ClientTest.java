package com.infotech.client;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


import com.infotech.model.Message;

public class ClientTest {

	public static void main(String[] args) {

		AbstractApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
		
		Message message1 = context.getBean("message1", Message.class);
		System.out.println(message1.getMessageId()+"\t"+message1.getMessage());
		context.close();
	
	}
}
