

public class Nazish2 extends Nazish {

	
	//giving error because method is static if we enable @override
	//@Override
	public void abs()
	{
		System.out.println("hSVH");
	}
	
}
