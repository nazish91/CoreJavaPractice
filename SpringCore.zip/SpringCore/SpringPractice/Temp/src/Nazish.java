import java.util.ArrayList;



public class Nazish {

	public static void abs()
	{
int n=2;
int temp=0;
int temp2=0;
ArrayList<Integer> sum=new ArrayList<Integer>();
	for (int i = 0; i < Math.pow(10, n); i++) {
		temp=i;
		for (int j = 1; j <=n; j++) {
			temp2=temp%10;
			sum.add(temp2);
			temp=temp/10;
		}
		
		for (int k = 0; k < n-1; k++) {
			if (sum.get(k)<sum.get(k+1) && k==n-2) {
				System.out.println(i);
				
				
			}
			else if (sum.get(k)>sum.get(k+1)) {
				System.out.println("skipping the number :"+i);
				
			} 
			
		}
	}
	
	
	
	}
	
	
	private static void generate(int prefix, int start, int n)
    {
        if (n == 0)
        {
            System.out.print(prefix);
            System.out.println();
        }
        else
        {
            for(int i=start;i<10;i++)
                generate(10*prefix+i, i+1, n-1);
        }
    }
	
	public static void main(String[] args) {
		int i,j;
		int k=0;
		k= j =i = 1;
		System.out.println(k);
	}

	
	

}
