package com.infotech.controller;

import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionAttributeListener;
import javax.servlet.http.HttpSessionBindingEvent;

@WebListener
public class MyHttpSessionAttributeListener implements HttpSessionAttributeListener {

    public void attributeAdded(HttpSessionBindingEvent hsbe) {
    	HttpSession session = hsbe.getSession();
    	Object attribute = session.getAttribute("userName");
    	if(attribute !=null){
    		System.out.println("A new attribute with value:"+(String)attribute+" is added is Session object");
    	}
    	
    	Object attribute1 = session.getAttribute("remoteAddr");
    	if(attribute1 !=null){
    		System.out.println("A new attribute with value:"+(String)attribute1+" is added is Session object");
    	}
    	
    }

    public void attributeRemoved(HttpSessionBindingEvent hsbe) {
    	HttpSession session = hsbe.getSession();
    	Object attribute = session.getAttribute("remoteAddr");
    	if(attribute ==null){
    		System.out.println("An attribute  is removed from session object");
    	}
    }
    public void attributeReplaced(HttpSessionBindingEvent hsbe) {
    	HttpSession session = hsbe.getSession();
    	Object attribute = session.getAttribute("userName");
    	if(attribute !=null){
    		System.out.println("An attribute is replaced with Value:"+(String)attribute+" in session object");
    	}
    }
	
}
