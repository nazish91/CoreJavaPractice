package com.infotech.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String driverName = null;
	String dbpassword = null;
	@Override
	public void init(ServletConfig config) throws ServletException {
		
	}
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String userName = request.getParameter("userName");
		String password = request.getParameter("password");
		RequestDispatcher requestDispatcher = null;
		
		System.out.println("Service method is called..");
		if(userName != null && !userName.isEmpty() && password != null && !password.isEmpty()){
			requestDispatcher = request.getRequestDispatcher("/welcome.jsp");
			request.setAttribute("userName", userName);
			requestDispatcher.forward(request, response);
		}else{
			requestDispatcher = request.getRequestDispatcher("/home.jsp");
			request.setAttribute("error", "Please enter userName & password!!");
			requestDispatcher.include(request, response);
		}
	}

	@Override
	public void destroy() {
		System.out.println("LoginServlet:Destroy() is called..");
	}
}
