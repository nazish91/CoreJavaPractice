package com.infotech.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class FirstServlet
 */
@WebServlet("/FirstServlet")
public class FirstServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name = request.getParameter("name");
		RequestDispatcher rd = null;
		//PrintWriter out = response.getWriter();
		if(name ==null || name.isEmpty()){
			request.setAttribute("error", "Name field can't be empty");
			//out.println("<font color='red'>"+"Name field can't be empty"+"</font>");
			rd = request.getRequestDispatcher("/index.jsp");
			rd.include(request, response);
		}else{
			HttpSession session = request.getSession(true);
			System.out.println("A new session is created With ID:"+session.getId());
			session.setAttribute("name", name);
			rd = request.getRequestDispatcher("/SecondServlet");
			rd.forward(request, response);
		}
	}

}
