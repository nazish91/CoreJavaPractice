public class Nazish2 {

	int a = 0;

	public Nazish2(int a) {
		this.a = a;
	}

	// remove void to consider as constructor
	public  Nazish2() {
		this(20);
		System.out.println(this);
		System.out.println("abc");
	}

	public void a() {
	}

	public static void main(String[] args) {
		Nazish2 a = new Nazish2();
	}
	public String toString() {
		return "my toString method..";
	}
	
	public Nazish2 getNazish2(){
		return this;
	}
}
