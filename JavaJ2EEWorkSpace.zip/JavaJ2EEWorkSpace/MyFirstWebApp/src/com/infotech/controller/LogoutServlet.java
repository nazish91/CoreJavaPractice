package com.infotech.controller;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LogoutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	public void init(ServletConfig config) throws ServletException {
		System.out.println("LogoutServlet:init() is called..");
		ServletContext servletContext = config.getServletContext();
		String fileLocation = servletContext.getInitParameter("FileLocation");
		System.out.println("fileLocation:"+fileLocation);
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}
	
	@Override
	public void destroy() {
		System.out.println("LogoutServlet:destroy() is called");
	}

}
