package com.infotech.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.SingleThreadModel;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class MyController
 */
@WebServlet("/MyController")
public class MyController extends HttpServlet implements SingleThreadModel {
	private static final long serialVersionUID = 1L;
	
	private static int counter=0;
	@Override
	public void init(ServletConfig config) throws ServletException {
	}
	
	@Override
	public void destroy() {
	}
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.sendRedirect("http://localhost:8080/MyWebApp2/");
		HttpSession session = request.getSession();
		ServletContext application = request.getServletContext();
		synchronized (response) {
			counter++;
		}
		RequestDispatcher requestDispatcher = request.getRequestDispatcher("/view/welcome.jsp");
		doGet(request, response);
	}
	
	/*@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		doPost(req, resp);
	}*/

}
