package com.infotech.service;

import java.util.ArrayList;
import java.util.List;

import com.infotech.model.Student;

public class StudentService {
	
	static List<Student> studentList = null;
	static{
		studentList = new ArrayList<>();
	}

	public boolean registerStudent(Student student){
		 return studentList.add(student);
	}

	public Student validateLogin(String email, String password) {
		for (Student student:studentList) {
			if(student.getEmail().equalsIgnoreCase(email)&& student.getPassword().equalsIgnoreCase(password)){
				return student;
			}
		}
		return null;
	}
}
