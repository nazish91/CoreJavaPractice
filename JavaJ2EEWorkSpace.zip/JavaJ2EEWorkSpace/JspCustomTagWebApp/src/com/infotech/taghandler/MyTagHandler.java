package com.infotech.taghandler;

import java.time.LocalDate;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.TagSupport;

public class MyTagHandler extends TagSupport{

private static final long serialVersionUID = 5373496941325008367L;

	public int doStartTag() throws JspException {
		JspWriter out = pageContext.getOut();// returns the instance of
		try {
			out.println(LocalDate.now());// printing date and
		} catch (Exception e) {
			System.out.println(e);
		}
		return SKIP_BODY;// will not evaluate the body content of the tag
	}
}
