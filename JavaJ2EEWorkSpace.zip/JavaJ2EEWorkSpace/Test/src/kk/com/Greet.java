package kk.com;

public class Greet extends Welcome {

 private  void test(){
		
	}
}
