package kk.com;

public class Welcome {

	private void test(){
		
	}
}
