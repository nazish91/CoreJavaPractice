package file.reader.writer.util;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;

public class ResourceUtil {

	public static void cleanupResource(Reader reader, Writer writer) {
		if(reader != null)
			try {
				reader.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		if(writer != null)
			try {
				writer.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
	}

}
