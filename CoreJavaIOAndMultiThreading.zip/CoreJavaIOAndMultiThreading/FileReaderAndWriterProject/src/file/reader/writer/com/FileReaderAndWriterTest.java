package file.reader.writer.com;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;

import file.reader.writer.util.ResourceUtil;

public class FileReaderAndWriterTest {

	public static void main(String[] args) {
		Reader reader = null;
		Writer writer = null;
		File outputFile = null;
		try {
			reader = new FileReader(new File("input1.txt"));
			outputFile = new File("ouput1.txt");
			writer = new FileWriter(outputFile);
			int c;
			while ((c=reader.read()) !=-1) {
				writer.write((char)c);
			}
			writer.flush();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}finally{
			ResourceUtil.cleanupResource(reader, writer);
		}
		System.out.println("Data is written in file:"+outputFile.getName());
	}
}
