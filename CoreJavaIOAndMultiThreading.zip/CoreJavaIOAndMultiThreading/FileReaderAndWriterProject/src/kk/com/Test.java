package kk.com;

public class Test {
	public static void main(String[] args) {
		
		int i=970;
		System.out.println((char)i);

	}

}
