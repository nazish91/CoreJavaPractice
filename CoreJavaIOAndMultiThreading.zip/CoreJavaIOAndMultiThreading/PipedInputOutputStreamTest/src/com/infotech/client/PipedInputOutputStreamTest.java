package com.infotech.client;

import java.io.IOException;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;

public class PipedInputOutputStreamTest {

	public static void main(String[] args) {
		//method1();
		method2();
	}

	private static void method2() {
		final PipedOutputStream pipedOutputStream;
		final PipedInputStream pipedInputStream ;
		try {
			pipedOutputStream = new PipedOutputStream();
			pipedInputStream = new PipedInputStream();
			pipedOutputStream.connect(pipedInputStream);
			
			Thread thread1 = new Thread(){
				public void run() {
					for (int i = 65; i <70; i++) {
						try {
							String name = "Nazish_"+i;
							pipedOutputStream.write(name.getBytes());
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				}
			};
			
			
			Thread thread2 = new Thread(){
				public void run() {
					for (int i =0; i <45; i++) {
						try {
							int read = pipedInputStream.read();
							System.out.print((char)read);
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				}
			};
			thread1.start();
			thread2.start();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	private static void method1() {
		final PipedOutputStream pipedOutputStream;
		final PipedInputStream pipedInputStream ;
		try {
			pipedOutputStream = new PipedOutputStream();
			pipedInputStream = new PipedInputStream();
			pipedOutputStream.connect(pipedInputStream);
			
			Thread thread1 = new Thread(){
				public void run() {
					for (int i = 65; i <70; i++) {
						try {
							pipedOutputStream.write((char)i);
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				}
			};
			
			
			Thread thread2 = new Thread(){
				public void run() {
					for (int i =0; i <5; i++) {
						try {
							int read = pipedInputStream.read();
							System.out.println((char)read);
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				}
			};
			thread1.start();
			thread2.start();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
