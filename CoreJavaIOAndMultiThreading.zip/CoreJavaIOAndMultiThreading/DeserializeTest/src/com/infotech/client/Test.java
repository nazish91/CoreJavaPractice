package com.infotech.client;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

import com.infotech.model.Employee;

public class Test {
	public static void main(String[] args) {

		ObjectInputStream inputStream = null;

		try {
			inputStream = new ObjectInputStream(new FileInputStream(
					"serialize.ser"));

			Object readObject = inputStream.readObject();
			if (readObject != null) {
				Employee employee = (Employee) readObject;
				System.out.println(employee.getName() + "\t"
						+ employee.getEmail() + "\t" + employee.getPassword()
						+ "\t" + employee.getAge());
			} else
				System.out.println("hi");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
