package com.infotech.client;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

import com.infotech.model.Employee;

public class DERTest {
	public static void main(String[] args) {

		ObjectInputStream inputStream = null;

		try {
			inputStream = new ObjectInputStream(new FileInputStream(
					"serialize.ser"));

			Object readObject = inputStream.readObject();
			if (readObject != null) {
				Employee employee = (Employee) readObject;
				System.out.println(employee.getName() + "\t"
						+ employee.getEmail() + "\t" + employee.getPassword()
						+ "\t" + employee.getAge());
				
				System.out.println("----------------------");
				System.out.println(employee.getPanNo()+"\t"+employee.getLocation());
			} else
				System.out.println("hi");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
