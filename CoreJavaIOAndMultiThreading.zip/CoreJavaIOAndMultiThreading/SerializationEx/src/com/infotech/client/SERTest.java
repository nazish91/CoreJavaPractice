package com.infotech.client;

import java.io.File;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

import com.infotech.model.Employee;

public class SERTest {

	public static void main(String[] args) {
		 ser();
	}

	private static void ser() {
		ObjectOutputStream objectOutputStream = null;
		OutputStream outputStream = null;
		try {
			outputStream = new FileOutputStream(new File("serialize.ser"));
			objectOutputStream = new ObjectOutputStream(outputStream);

			Employee employee = new Employee("KJKA66hH", "Pune");
			employee.setEmail("nazish.a@gmail.com");
			employee.setPassword("p@123");
			employee.setName("Nazish");
			objectOutputStream.writeObject(employee);
			System.out.println("Object is serialized..");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
