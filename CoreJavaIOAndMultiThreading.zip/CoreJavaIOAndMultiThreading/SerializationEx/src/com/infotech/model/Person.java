package com.infotech.model;

public class Person {

	public Person() {
	}
	private  String panNo;
	private String location;
	public Person(String panNo, String location) {
		super();
		this.panNo = panNo;
		this.location = location;
	}
	public String getPanNo() {
		return panNo;
	}
	public String getLocation() {
		return location;
	}
}
