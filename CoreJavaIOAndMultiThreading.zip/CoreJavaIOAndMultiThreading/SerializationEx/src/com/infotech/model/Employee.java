package com.infotech.model;

import java.io.Serializable;

public class Employee extends Person implements Serializable{

	public Employee() {
		super("HJSHJS88JJ","Pune");
	}
	public Employee(String panNo, String location) {
		super(panNo, location);
	}
	private static final long serialVersionUID = -588750510046123501L;
	private String name;
	private String email;
	private transient String password;
	private int age;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
}
