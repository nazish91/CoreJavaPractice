package com.infotech.model;

public interface Hello {
void test();
}
