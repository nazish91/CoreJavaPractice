package file.input.output.stream;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

public class Test {

	public static void main(String[] args) {
		InputStream inputStream = null;
		OutputStream outputStream = null;
		File outputFile = null;

		try {
			/*inputStream = new FileInputStream(
					"D:\\JavaWorkSpace\\IO\\BinaryInputFiles\\eclipseshortcuts.pdf");
		*/	inputStream = new FileInputStream(
					"C:\\Users\\FAIZAN\\Desktop\\abc.txt");
		System.out.println(inputStream.available());
			
			/*outputStream = new FileOutputStream(outputFile = new File(
					"D:/JavaWorkSpace/IO/BinaryOutputFiles/eclipseshortcuts2.pdf"));
	*/	//we do not have to give the full path in case if we have already created the 
		//file in our project folder
		outputStream = new FileOutputStream("Java");

			int c;
			while ((c = inputStream.read()) != -1) {
				try {
					outputStream.write((char) c);
					//System.out.println(c);
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
			outputStream.flush();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		//System.out.println("Data is written in file:"+outputFile.getAbsolutePath());
		System.out.println("Data is written in file:");
		
	}

}
