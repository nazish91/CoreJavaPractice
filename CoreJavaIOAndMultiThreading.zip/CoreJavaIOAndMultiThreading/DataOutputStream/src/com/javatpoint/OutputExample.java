package com.javatpoint;  
  
import java.io.*;
import java.io.Console; 
public class OutputExample {/*  
    public static void main(String[] args) throws IOException {  
        FileOutputStream file = new FileOutputStream("out.txt");  
        DataOutputStream data = new DataOutputStream(file); 
        
        data.writeInt(65); 
        //data.writeByte(65);
        FileInputStream fileInputStream = new FileInputStream("out.txt");
       // System.out.println(fileInputStream.read());
        int i;
        while ((i=fileInputStream.read())!=-1) {
			System.out.println(i);
		}
        
        //data.flush();  
        data.close();  
        System.out.println("Succcess...");  
    }  
*/
	

	public static void main(String args[]){    
		Console c=System.console();   
		char[] readPassword = c.readPassword();
		System.out.println("Enter your name: ");    
		String n=c.readLine();    
		System.out.println("Welcome "+n+readPassword);    
		}    }