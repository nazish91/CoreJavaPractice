package com.read.file.names;

import java.io.File;

public class ReadFilenamesFromDirectoryTest {

	public static void main(String[] args) {

		String directoryLoc = "D:\\JavaWorkSpace\\CoreJavaIOWorkSpace\\FileReaderAndWriterProject\\";
		File file = new File(directoryLoc);
		if(file.isFile() || !file.isDirectory()){
			System.out.println("provided location is a file:");
			return ;
		}else if(file.isDirectory()){
			String[] fileNameList = file.list();
			for (String fileName : fileNameList) {
				System.out.println(fileName);
			}
		}
	}

}
