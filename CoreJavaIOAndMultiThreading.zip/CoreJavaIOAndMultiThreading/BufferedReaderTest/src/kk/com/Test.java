package kk.com;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Reader;

public class Test {
	
	public static void main(String[] args) {

		Reader reader;
		BufferedReader bufferedReader = null;
		try {
			reader = new FileReader("input1.txt");
			bufferedReader = new BufferedReader(reader);
			while(bufferedReader.readLine() != null){
				System.out.println(bufferedReader.readLine());
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
