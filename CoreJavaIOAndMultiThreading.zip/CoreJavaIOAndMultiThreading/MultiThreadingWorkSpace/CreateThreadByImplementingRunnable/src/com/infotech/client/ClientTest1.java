package com.infotech.client;

import com.infotech.thread.MyThread;

public class ClientTest1 {

	public static void main(String[] args) {

		MyThread myThread = new MyThread();
		
		Thread t1 = new Thread(myThread,"MyThread_1");
		Thread t2 = new Thread(myThread,"MyThread_2");
		Thread t3 = new Thread(myThread,"MyThread_3");
		
		t1.start();
		t2.start();
		t3.start();
		//we can get the name of any thread by its object
		System.out.println("yes we are here  :"+t1.getName());
		
		System.out.println("Thread:"+Thread.currentThread().getName()+" :executing..");
		System.out.println("Main end..");
	}
}
