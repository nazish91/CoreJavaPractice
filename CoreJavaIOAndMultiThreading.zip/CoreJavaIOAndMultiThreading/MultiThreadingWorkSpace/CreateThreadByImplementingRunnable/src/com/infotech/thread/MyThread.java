package com.infotech.thread;

public class MyThread implements Runnable {

	public void run() {
		for (int i = 1; i < 6; i++) {
			try {
				//else here we can print thread name of current thread
				System.out.println("Thread:"+Thread.currentThread().getName()+" executing..");
				System.out.println(i);
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
			
	}
}
