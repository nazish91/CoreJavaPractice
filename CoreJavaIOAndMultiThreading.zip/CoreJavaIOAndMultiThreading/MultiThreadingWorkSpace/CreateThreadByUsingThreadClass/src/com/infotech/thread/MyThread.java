package com.infotech.thread;

public class MyThread extends Thread {
	
	public void run() {
		for (int i = 1; i < 6; i++) {
			try {
				System.out.println("Thread:"+Thread.currentThread().getName()+" executing..");
				System.out.println(i);
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
