package com.infotech.client;

public class ClientTest1 {

	public static void main(String[] args) {
		
		Thread thread1 = new Thread(){
			public void run() {

				for (int i = 1; i < 6; i++) {
					try {
						System.out.println("Thread:"+Thread.currentThread().getName()+" executing..");
						System.out.println(i);
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			
			}
		};
		
		Thread thread2 = new Thread(){
			public void run() {

				for (int i = 1; i < 6; i++) {
					try {
						System.out.println("Thread:"+Thread.currentThread().getName()+" executing..");
						System.out.println(i);
						Thread.sleep(2000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			
			}
		};
		
		thread1.start();
		thread2.start();
	}
}
