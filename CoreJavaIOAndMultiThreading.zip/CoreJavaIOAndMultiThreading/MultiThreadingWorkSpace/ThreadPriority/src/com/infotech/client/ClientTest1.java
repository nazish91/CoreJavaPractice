package com.infotech.client;

import com.infotech.thread.MyThread;

public class ClientTest1 {

	public static void main(String[] args) {

		MyThread myThread = new MyThread();
		
		Thread t1 = new Thread(myThread,"MyThread_1");
		t1.setPriority(Thread.MIN_PRIORITY);
		Thread t2 = new Thread(myThread,"MyThread_2");
		Thread t3 = new Thread(myThread,"MyThread_3");
		t3.setPriority(Thread.MAX_PRIORITY);
		
		t1.start();
		t2.start();
		t3.start();
		
		System.out.println("Thread:"+Thread.currentThread().getName()+" :executing..");
		System.out.println("Main end..");
	}
}
