package kk.com.counter;

public class JoinTest {

	public static void main(String[] args) {

		Thread thread1 = new Thread("t1"){
			public void run() {
				System.out.println(Thread.currentThread().getName());
				for (int i = 1; i <=5; i++) {
					System.out.println(i);
				}
			}
		};
		
		Thread thread2 = new Thread("t2"){
			public void run() {
				System.out.println(Thread.currentThread().getName());
				for (int i = 1; i <=5; i++) {
					System.out.println(i);
				}
			}
		};
		
		Thread thread3 = new Thread("t3"){
			public void run() {
				System.out.println(Thread.currentThread().getName());
				for (int i = 1; i <=5; i++) {
					System.out.println(i);
				}
			}
		};
		
		thread1.start();
		
		try {
			thread1.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
		thread2.start();
		
		try {
			thread2.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		thread3.start();
	}
}
