package com.kk.client;

import com.infotech.thread.MyThread;

public class Test {

	public static void main(String[] args) {
		System.out.println("Main start..");
		MyThread myThread = new MyThread();
		Thread thread1 = new Thread(myThread);
		thread1.setDaemon(true);
		
		thread1.start();
		
		System.out.println("Main end..");

	}
}
