package com.infotech.thread;

public class MyThread implements Runnable {

	public void run() {
		for (int i = 1; i < 6; i++) {
			System.out.println(i);
			
			try {
				Thread.sleep(300);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
