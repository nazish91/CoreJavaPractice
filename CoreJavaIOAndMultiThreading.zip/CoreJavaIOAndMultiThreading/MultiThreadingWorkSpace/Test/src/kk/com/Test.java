package kk.com;

public class Test {
	public static void main(String[] args) {

		MyThread myThread = new MyThread();
		Thread thread1 = new Thread(myThread);
		
		thread1.start();
		thread1.start();
	}

}
