package kk.com;

public class MyThread implements Runnable {

	public void run() {
		System.out.println("Running....");
	}
}
