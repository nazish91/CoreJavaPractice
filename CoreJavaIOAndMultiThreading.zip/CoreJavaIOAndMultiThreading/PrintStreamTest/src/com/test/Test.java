package com.test;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.PrintStream;

public class Test {

	public static void main(String[] args) {
		System.out.println("Hello.");
		System.err.println("Error!!!!!");
		System.out.printf("%d", 40);
		
		OutputStream outputStream = null;
		PrintStream printStream = null;
		try {
			outputStream = new FileOutputStream(new File("out.txt"));
			printStream = new PrintStream(outputStream);
			String str = "Write into file";
			printStream.write(str.getBytes());
			
			printStream.flush();
			outputStream.flush();
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			
		}
	}

}
