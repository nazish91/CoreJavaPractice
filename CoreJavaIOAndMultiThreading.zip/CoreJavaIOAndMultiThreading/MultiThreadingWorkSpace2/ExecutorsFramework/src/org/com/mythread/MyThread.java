package org.com.mythread;

import java.util.concurrent.Callable;

public class MyThread implements Callable<Long> {

	private int number;
	public MyThread(int number) {
		this.number = number;
	}
	long sum = 0;
	@Override
	public Long call() throws Exception {
		for (int i = 1; i <=number; i++) {
			sum = sum+i;
		}
		return sum;
	}


}
