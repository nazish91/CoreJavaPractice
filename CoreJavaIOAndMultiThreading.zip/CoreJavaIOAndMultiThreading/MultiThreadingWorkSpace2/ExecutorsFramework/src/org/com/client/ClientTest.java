package org.com.client;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.com.mythread.MyThread;

public class ClientTest {

	public static void main(String[] args) {

		ExecutorService executorService = Executors.newFixedThreadPool(1);
		//executorService.awaitTermination(arg0, arg2)
		
		Future<Long> future = executorService.submit(new MyThread(11));
		try {
			Long sum = future.get();
			System.out.println(sum);
		} catch (InterruptedException | ExecutionException e) {
			e.printStackTrace();
		}
	}
}
