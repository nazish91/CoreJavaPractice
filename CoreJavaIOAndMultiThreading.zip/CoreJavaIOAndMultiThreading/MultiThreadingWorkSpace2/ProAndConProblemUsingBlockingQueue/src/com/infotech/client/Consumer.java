package com.infotech.client;

import java.util.concurrent.BlockingQueue;

public class Consumer implements Runnable{

	private BlockingQueue<Integer> queue = null;
	
	public Consumer(BlockingQueue<Integer> queue) {
		this.queue = queue;
	}
	@Override
	public void run() {

		while (true) {
			try {
				Integer data = queue.take();
				System.out.println("Consumed:"+data);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
