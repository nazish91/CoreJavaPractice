package com.infotech.client;

import java.util.Random;
import java.util.concurrent.BlockingQueue;

public class Producer implements Runnable{

	private BlockingQueue<Integer> queue = null;
	
	public static final int MAX_SIZE = 1;
	
	public Producer(BlockingQueue<Integer> queue) {
		this.queue = queue;
	}

	@Override
	public void run() {
		Random random = new Random();
		while (true) {
			int data = random.nextInt(10);
			System.out.println("Produced:"+data);
			try {
				queue.put(data);
				Thread.sleep(1000);
			} catch (InterruptedException e1) {
				e1.printStackTrace();
			}
		}
	}

}
