package com.infotech.client;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class ClienTest {

	public static void main(String[] args) {
		
		BlockingQueue<Integer> queue = new LinkedBlockingQueue<>(1);

		Producer producer = new Producer(queue);
		Consumer consumer = new Consumer(queue);
		
		Thread t1 = new Thread(producer);
		Thread t2 = new Thread(consumer);
		
		t1.start();
		t2.start();
	}
}
