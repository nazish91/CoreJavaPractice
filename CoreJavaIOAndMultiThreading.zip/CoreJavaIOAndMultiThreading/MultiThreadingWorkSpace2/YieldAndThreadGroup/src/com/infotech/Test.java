package com.infotech;

public class Test {

	public static void main(String[] args) {

		Runnable runnable = new MyThread();
		
		ThreadGroup group1 = new ThreadGroup("AllThread Group1");
		ThreadGroup group2 = new ThreadGroup("AllThread Group2");
		Thread t1 = new Thread(group1, runnable, "T1");
		Thread t2 = new Thread(group1, runnable, "T2");
		Thread t3 = new Thread(group1, runnable, "T3");
		
		
		Thread t4 = new Thread(group2, runnable, "T4");
		Thread t5 = new Thread(group2, runnable, "T5");
		Thread t6 = new Thread(group2, runnable, "T6");
		//group2.setMaxPriority(Thread.MAX_PRIORITY);
		
		
		group1.list();
		
		t1.start();
		t2.start();
		t3.start();
		
		t4.start();
		t5.start();
		t6.start();
		
		while (true) {
			System.out.println(System.nanoTime()+" Thread T1 state:"+t1.getState());
			System.out.println(System.nanoTime()+" Thread T2 state:"+t2.getState());
			System.out.println(System.nanoTime()+" Thread T3 state:"+t3.getState());
			System.out.println(System.nanoTime()+" Thread T4 state:"+t4.getState());
			System.out.println(System.nanoTime()+" Thread T5 state:"+t5.getState());
			System.out.println(System.nanoTime()+" Thread T6 state:"+t6.getState());
			
			if(group1.activeCount() ==0 && group2.activeCount() == 0){
				break;
			}
		}
	}
}
