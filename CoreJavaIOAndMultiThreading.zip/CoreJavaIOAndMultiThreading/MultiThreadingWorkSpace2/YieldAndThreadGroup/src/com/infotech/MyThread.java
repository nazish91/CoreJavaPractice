package com.infotech;

public class MyThread implements Runnable {

	public void run() {
		System.out.println(Thread.currentThread().getName()+" started..");
		Thread.yield();
		try {
			Thread.sleep(50);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println(Thread.currentThread().getName()+" End..");
	}
}
