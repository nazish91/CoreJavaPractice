package com.infotech.client;

import java.util.Queue;
import java.util.Random;

public class Producer implements Runnable{

	private Queue<Integer> queue = null;
	
	public static final int MAX_SIZE = 1;
	
	public Producer(Queue<Integer> queue) {
		this.queue = queue;
	}

	@Override
	public void run() {
		Random random = new Random();
		while (true) {
			synchronized (queue) {
				while (MAX_SIZE == queue.size()) {
					try {
						System.out.println("Waiting to be consumed..");
						queue.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				
				int data = random.nextInt(10);
				System.out.println("Produced:"+data);
				
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				queue.add(data);
				queue.notify();
			}
		}
	}

}
