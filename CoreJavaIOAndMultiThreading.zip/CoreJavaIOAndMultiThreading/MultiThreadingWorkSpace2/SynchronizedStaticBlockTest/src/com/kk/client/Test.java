package com.kk.client;

import com.kk.table.Table;

public class Test {

	public static void main(String[] args) {

		Thread t1 = new Thread("MyThread_1"){
			public void run() {
				Table.printTable(1);
			}
		};
		
		Thread t2 = new Thread("MyThread_2"){
			public void run() {
				Table.printTable(10);
			}
		};
		
		t1.setPriority(Thread.MIN_PRIORITY);
		t1.start();
		t2.start();
		
	}

}
