package com.kk.client;

import static com.kk.table.Table.printTable;

public class Test {

	public static void main(String[] args) {

		Thread t1 = new Thread("MyThread_1"){
			public void run() {
				printTable(1);
			}
		};
		
		Thread t2 = new Thread("MyThread_2"){
			public void run() {
				printTable(10);
			}
		};
		
		t1.setPriority(Thread.MIN_PRIORITY);
		t1.start();
		t2.start();
		
	}

}
