package kk.com.client;

public class DeanLockAvoidTest {

	public static void main(String[] args) {

		final String resource1 = "Resource1";
		final String resource2 = "Resource2";
		
		Thread thread1 = new Thread(){
			@Override
			public void run() {
				synchronized (resource1) {
					System.out.println("Thread1: locked Resource1");
					
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					synchronized (resource2) {
						System.out.println("Thread1: locked Resource2");
					}
				}
			}
		};
		
		Thread thread2 = new Thread(){
			@Override
			public void run() {
				synchronized (resource1) {
					System.out.println("Thread2: locked Resource1");
					try {
						Thread.sleep(1000);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
					synchronized (resource2) {
						System.out.println("Thread2: locked Resource2");
					}
				}
			}
		};
		thread1.start();
		thread2.start();
	}

}
