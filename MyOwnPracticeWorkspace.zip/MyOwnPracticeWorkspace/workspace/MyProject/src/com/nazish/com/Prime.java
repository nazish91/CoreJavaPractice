package com.nazish.com;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Prime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");

		Hotel hotel = context.getBean("anyName", Hotel.class);
		if (hotel != null) {

			hotel.wish();
		}
	}

}
