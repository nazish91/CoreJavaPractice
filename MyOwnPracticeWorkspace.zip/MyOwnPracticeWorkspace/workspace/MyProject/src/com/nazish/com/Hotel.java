package com.nazish.com;

public class Hotel {

	public void wish()
	{
		System.out.println("welcome in the hotel");
	}

}
