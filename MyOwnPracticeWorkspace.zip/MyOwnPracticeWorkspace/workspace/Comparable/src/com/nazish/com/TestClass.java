package com.nazish.com;
/* IMPORTANT: Multiple classes and nested static classes are supported */

/*
 * uncomment this if you want to read input.
//imports for BufferedReader
import java.io.BufferedReader;
import java.io.InputStreamReader;

//import for Scanner and other utility classes*/
import java.util.*;
import java.util.Map.*;
import java.util.Map.Entry;


// Warning: Printing unwanted or ill-formatted data to output will cause the test cases to fail
class TestClass {
    public static void main(String args[] ) throws Exception {
         //Sample code to perform I/O:
         // Use either of these methods for input

        //BufferedReader
        //BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        //String name = br.readLine();                // Reading input from STDIN
        //System.out.println("Hi, " + name + ".");    // Writing output to STDOUT
         
        //Scanner
        Map<Integer,Integer> map = new LinkedHashMap<Integer,Integer>();
        Scanner sc = new Scanner(System.in);
        String lq = sc.nextLine();                 // Reading input from STDIN
        String[] s = lq.split(" ");
        int length = Integer.parseInt(s[0]);
        int query = Integer.parseInt(s[1]);
        int[] a = new int[length];
        boolean present = false;
        while(query > 0)
        {
            String q = sc.nextLine(); 
            String[] si = q.split(" ");
            int qNo = Integer.parseInt(si[0]);
            int val = Integer.parseInt(si[1]);
            //map.put(qNo , val);
            if(qNo == 1)
            {
                a[val] = -1;
            }
            else
            {
                for(int i=val ; i<a.length ; i++)
                {
                    if(a[i] == -1)
                    {
                        System.out.println(i);
                        present  = true;
                        break;
                    }
                }
                if(!present)
                {
                    System.out.println(-1);
                }
            }
            query--;
        }
        
       for(Map.Entry<Integer,Integer> entry : map.entrySet())
        {
            if(entry.getKey() == 1)
            {
                a[entry.getValue()] = -1;
            }
            else
            {
                int y = entry.getValue();
                for(int i=entry.getValue() ; i<a.length ; i++)
                {
                    if(a[i] == -1)
                    {
                        System.out.println(i);
                        present  = true;
                        break;
                    }
                }
                if(!present)
                {
                    System.out.println(-1);
                }
            }
        }

    }
}

    /*public static void main(String args[] ) throws Exception {
         Sample code to perform I/O:
         * Use either of these methods for input

        //BufferedReader
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String name = br.readLine();                // Reading input from STDIN
        System.out.println("Hi, " + name + ".");    // Writing output to STDOUT
         
        //Scanner
        Map<Integer,Integer> map = new LinkedHashMap<Integer,Integer>();
        Scanner sc = new Scanner(System.in);
        String lq = sc.nextLine();                 // Reading input from STDIN
        String[] s = lq.split(" ");
        int length = Integer.parseInt(s[0]);
        int query = Integer.parseInt(s[1]);
        int[] a = new int[length];
        boolean present = false;
        while(query > 0)
        {
            String q = sc.nextLine(); 
            String[] si = q.split(" ");
            int qNo = Integer.parseInt(si[0]);
            int val = Integer.parseInt(si[1]);
            System.out.println(qNo+"*"+val );
            map.put(qNo , val);
            query--;
        }
        
       for(Map.Entry<Integer,Integer> entry : map.entrySet())
        {
            if(entry.getKey() == 1)
            {
                a[entry.getValue()] = -1;
                for(int i = 0 ; i<a.length ; i++)
                	System.out.println(a[i]);
            }
            else
            {
                int y = entry.getValue();
                for(int i=entry.getValue() ; i<a.length ; i++)
                {
                    if(a[i] == -1)
                    {
                        System.out.println(i);
                        present  = true;
                        break;
                    }
                }
                if(!present)
                {
                    System.out.println(-1);
                }
            }
        }

    }
}
*/