package com.nazish.com;


public class Aclass extends Thread implements Runnable{
	
	public static void main(String[] args) {
		
	Aclass aclass = new Aclass();
	Aclass aclass2 = new Aclass();
	
	System.out.println(aclass.equals(aclass2));
	
	
     (new Thread(aclass)).start();
    	
	}
	

	/*@Override
	private void run() {
		System.out.println("Run");
	}
*/
	

	
	
}