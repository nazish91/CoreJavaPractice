package com.nazish.com;

public class Today {
	
	int a;
	
	void m1(Today t)
	{
	System.out.println("objet");	
	}
	
	void m1(String t)
	{
		System.out.println("String");
	}
	public static void main(String[] args) {
		
	
	
	
	}
	   @Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + a;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Today other = (Today) obj;
		if (a != other.a)
			return false;
		return true;
	}

		static int solution(int[] A, int X) {
	        int N = A.length;
	        if (N == 0) {
	            return -1;
	        }
	        int l = 0;
	        int r = N - 1;
	        while (l <= r) {
	            int m = (l + r) / 2;
	            if (A[m] >= X) {
	                r = m - 1;
	            } else {
	                l= m + 1;
	            }
	        }
	        if (A[l] == X) {
	            return l;
	        }
	        return -1;
	    }
	

}
