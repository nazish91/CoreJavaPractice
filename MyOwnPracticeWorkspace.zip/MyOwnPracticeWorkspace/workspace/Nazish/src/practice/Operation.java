package practice;

import java.util.StringTokenizer;



public class Operation{  
 
	  
     String tokenizer()
 {
	 String s= "Nazish Ansari";
	  StringTokenizer st = new StringTokenizer("Nazish Ansari"," "); 
	  
		String s1 =  st.nextToken();
		String s2 =  st.nextToken();
		
		//System.out.println(s2 +"," +s1.substring(0,1));
		String d =s2 + s1.substring(0,1);
	 
	 
 
	  return d;
 }
	 
	  public static void main (String[] args)
	  {
		  
		  Operation opt = new Operation();
		  System.out.println(opt.tokenizer());
		  
	  }
	
		 
		 
	  	 
	 
	}  
