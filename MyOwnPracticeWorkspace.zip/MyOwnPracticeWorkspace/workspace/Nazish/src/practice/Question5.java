package practice;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class Question5 {

	public static void main(String[] args) {

      String[] yo = {"3","4","5"};
      //List<String> al3 = (Arrays.asList(yo));
     
       
      //System.out.println(al3);
      
		ArrayList<Integer> al=new ArrayList<>();
		al.add(1);
		al.add(3);
		al.add(5);
		al.add(7);
		al.add(9);
		al.add(12);
		al.add(36);
		al.add(54);
		al.add(72);
		al.add(57);
		ArrayList<Integer> al2=new ArrayList<>();
		al2.add(2);
		al2.add(4);
		al2.add(6);
		al2.add(8);
		al2.add(10);
		List<Integer> l2= Collections.unmodifiableList(al2);
		l2.add(99);
		l2.set(2,33);
		//System.out.println(al2);
		System.out.println(l2);
		
		//System.out.println(al2);
		/*ArrayList<Integer> al3=new ArrayList<>();
		for(int i=0;i<al.size();i++)
		{
			if((i+1)%3!=0)
			{
				al3.add(al.get(i));
			}
			else
			{
				al3.add(al2.get(i));
			}
			
		}
		
		System.out.println(al3);
		*/
		
	}
}