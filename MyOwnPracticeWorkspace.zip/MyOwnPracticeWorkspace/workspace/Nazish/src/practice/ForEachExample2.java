package practice;

import java.util.*;

class ForEachExample2 {
	public static void main(String args[]) {
		HashSet<String> list = new HashSet<String>();
		list.add("vimal");
		list.add("sonoo");
		list.add("ratan");

		// for(String s:list)
		System.out.println(list);
		System.out.println(tryCatchTrial());
		System.out.println("hj");

	}

	static int tryCatchTrial() {
		try {
			int c=9/0;
		} catch (Exception e) {
			System.out.println("in catch");
			return 8;
		} finally {
			return 9;
		}
	}
}