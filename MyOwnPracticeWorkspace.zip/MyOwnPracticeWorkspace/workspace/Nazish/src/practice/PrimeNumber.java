package practice;

public class PrimeNumber {

	

	void raju() {
		
		int n = 11;
		int count=0;
		for (int i = 2; i < n / 2; i++) {

			if (n % i == 0) {
				System.out.println("not prime");
				count = 1;
				break;
			} 
			else {
				count =  0;
			}
		}
		if (count== 0) {
			System.out.println("prime");
		} 
	}

	public static void main(String[] args) {

		PrimeNumber l = new PrimeNumber();
		l.raju();

	}
}