package practice;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.StringTokenizer;

public class Bharat {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		
		/*String a = "cajhcb677bajha87babch98jjk98bhjdab";
		
		
		String b=a.replaceAll("[0-9]", "");
	   
	   System.out.println(b);
		*/
		
		String b = "this is lab";
		
		String a= "ncbis njs is jkdsjk is nh is nhb is kj";
		
		StringTokenizer t = new StringTokenizer(a," ");
		//StringTokenizer t2 = new StringTokenizer(b," ");
			System.out.println("t.countTokens():::::"+t.countTokens());
			int count=0;
			for (int i = 0; i < (t.countTokens()*2); i++) {
				
				System.out.println(t.nextToken());
				System.out.println("iiii"+i);
				
			}	
			
			while(t.hasMoreTokens())
			{
				//System.out.println(t.nextToken());
			}
			System.out.println(count);
				
		/*String s = "LKJHG6714N";
		
		if(s.matches("[A-Z]{5}[0-9]{4}[A-Z]{1}"))
		{
			System.out.println("this is valid");
		}
		else
		{
			System.out.println("not valid");
		}
*//*ArrayList<Integer> al=new ArrayList<>();
al.add(1);
al.add(2);
al.add(3);
al.add(8);
ArrayList<Integer> al2=new ArrayList<>();
al2.add(3);
al2.add(2);
al2.add(5);
al2.add(9);


al.retainAll(al2);



Integer []arr=new Integer[al.size()];
al.toArray(arr);
for(Integer k:arr)
{
	System.out.println(k);
	

//System.out.println(al);


//Iterator<Integer> l=al.iterator();
//while(l.hasNext())
//{
	//System.out.println(l.next());
*/	
			
			
		
}


}

	


