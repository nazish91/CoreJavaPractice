package practice;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class Ram {

	
	
	public static void main(String[] args) {
		Map<Integer, String> hm = new HashMap<Integer,String>();
		hm.put(22, "raju");
		hm.put(24, "babu");
		hm.put(32, "anni");
		hm.put(48, "arvind");
		hm.put(21, "lala");
		
		int count=0;
		for(Entry<Integer, String> m1:hm.entrySet()){  
		   // System.out.println("Key = " + m1.getKey() + ", Value = " + m1.getValue());
			
			if(m1.getKey()%4==0)
			{
				count++;
				
			}
			
		}
		System.out.println(count);
		
		
	}

}
