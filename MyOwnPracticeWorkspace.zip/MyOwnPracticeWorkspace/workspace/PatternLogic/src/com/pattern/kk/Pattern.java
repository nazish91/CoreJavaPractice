package com.pattern.kk;

import java.util.Arrays;

public class Pattern {

	public static void main(String[] args) {
		/*for (int i = 4; i >0; i--) {
			for (int k = 0; k <4-i; k++) {
				System.out.print(" ");
			}
			for (int j = 0; j < i; j++) {
				System.out.print("*");
			}
		System.out.println();	
		}*/
		
		
		
		
		
		/*for (int i = 1; i <= 4; i++) 
        {
            for (int j = 1; j <= i; j++)
            {
                System.out.print(j);
            }
             
            System.out.println();
        }
		
		
		
	}
*/
	int arr[]={1,6,9,5,4,3,2,88,55};	
		int temp=0;
		for(int i=0; i < arr.length; i++){  
            for(int j=1; j < (arr.length-i); j++){  
                     if(arr[j-1] > arr[j]){  
                            //swap elements  
                            temp = arr[j-1];  
                            arr[j-1] = arr[j];  
                            arr[j] = temp;  
                    }  
                     
            }  

	
	
		}
		System.out.println(Arrays.toString(arr));}}

