package src;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class MyServlets
 */
@WebServlet("/MyServlets")
public class MyServlets extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public MyServlets() {
        super();
        // TODO Auto-generated constructor stub
    }
    protected void doPost(HttpServletRequest request,
	HttpServletResponse response) throws ServletException, IOException 
	{
		String u = request.getParameter("uname");
		String p = request.getParameter("pwd");
		System.out.println(u);
		System.out.println(p);
		ResultSet rs;
		String q= "select * from credentials where username = '"+u+"' and password = '"+p+"'";
		Connection con= null;
		try
		{
			Class.forName("com.mysql.jdbc.Driver").newInstance();
			System.out.println("Entered");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/DBSUPER", "root","nazish");
			System.out.println("connection Established");
			
			PreparedStatement ps=con.prepareStatement(q);
			
			System.out.println(q);
			
            rs=ps.executeQuery();
            System.out.println("done2");
            
          if (rs.next()) 
            {
               response.sendRedirect("success.jsp");
            }
          else
        	  response.sendRedirect("failed.jsp");
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}
	}
	
   
   

}
