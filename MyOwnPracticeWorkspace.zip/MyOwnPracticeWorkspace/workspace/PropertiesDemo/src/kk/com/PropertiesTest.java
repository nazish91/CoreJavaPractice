package kk.com;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;

public class PropertiesTest {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		//getSystemProperties();
		readDataFromPropertiesFile();
	}

	private static void readDataFromPropertiesFile() throws FileNotFoundException, IOException {
		Properties properties = new Properties();
		
		properties.load(new FileInputStream("database.properties"));
		
		System.out.println(properties.getProperty("driver.class.name"));
		System.out.println(properties.getProperty("db.url"));
		System.out.println(properties.getProperty("db.username"));
		System.out.println(properties.getProperty("db.password"));
		
	}

	private static void getSystemProperties() {
		Properties properties = System.getProperties();
		
		Set<Entry<Object, Object>> entrySet = properties.entrySet();
		for (Entry<Object, Object> entry : entrySet) {
			System.out.println(entry.getKey());
			System.out.println(entry.getValue());
			
			System.out.println("------------------------------------");
		}
	}

}
