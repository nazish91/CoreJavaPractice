package stringQues;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class StringRepeatedChar {

	public Set<String> FindRptdChar(String s)
	{
		Set<String> set= new HashSet<>();
		char[] charArray=s.toCharArray();
		Map<String, Integer> m=new HashMap<>();
		for(char tem:charArray)
		{
			String temp=""+tem;
			if(m.containsKey(temp))
			{
				m.put(temp,m.get(temp)+1);
			}
			else
				m.put(temp, 1);
			
		}
		System.out.println(m);
		for(Map.Entry<String, Integer> eSet:m.entrySet())
		{
			if(eSet.getValue()>1)
				set.add(eSet.getKey());
		}
		return set;
	}
	
	public static void main(String[] ars)
	{
		StringRepeatedChar src=new StringRepeatedChar();
		System.out.println(src.FindRptdChar("programming"));
	}
}

