package kk.com;

import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class HashtableAndConcurrentHashMapTest {

	public static void main(String[] args) {

		//Map<String, String> map = new Hashtable<>();
		Map<String, String> map = new ConcurrentHashMap<>();
//		Map<String, String> map = new Hashtable<>();
		map.put("Zanish", "Pune");
		map.put("Ahmad", "Mumbai");
//		map.put(null, "MN");
		
		Set<String> keySet = map.keySet();
		
		for(String name:keySet){
			System.out.println(name);
			System.out.println(map.get(name));
			if(name.equals("Kishan"))
			map.remove(name);
		}
	}

}
