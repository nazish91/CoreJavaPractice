package com.java2novice.arraylist;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

public class CompAndcomptrEXM {

	public static void main(String a[]) {

		
		//because it is list we can not sort it  simply by comparator and comparable
		//we have one method collections.sort(list,comparator c)for comparator and collections.sort(list)
		//for comparable
		//employee class is implementing comparable so it can be sorted simply by sort method 
		//without passing any comparator for DNSO
		/*List<MyNameComp1> list = new ArrayList<MyNameComp1>();
		list.add(new MyNameComp1("Ram", 3000));
		list.add(new MyNameComp1("John", 6000));
		list.add(new MyNameComp1("Crish", 2000));
		list.add(new MyNameComp1("Tom", 2400));*/
		
		
		List<Empl> list = new ArrayList<Empl>();
		list.add(new Empl("Ram", 3000));
		list.add(new Empl("John", 6000));
		list.add(new Empl("Crish", 2000));
		list.add(new Empl("Tom", 2400));
		
		List<String> list1 = new ArrayList<String>();
		list1.add("ram");
		list1.add("kareem");
		list1.add("paresh");
		list1.add("rawal");
		System.out.println(list1.get(list1.indexOf("ram")));
		
		//here we can pass any of the two comparator to that list so that they can be 
		//sorted on the basis of salary and name respt.
		MySalaryComp mySalaryComp = new MySalaryComp();
		MyNameComp s =new MyNameComp();
		
		
		//this is not necessary that EMP class is implementing comparable 
		//then it will sorted on the basis of it priority would be comparator 
		//if we pass that in sort method after comma
		//after comma separator we can pass that comparator
		Collections.sort(list,mySalaryComp);
		System.out.println("Sorted list entries: " + list);
		
		//this string type objects are sorted because String class already implements comparable interface
		
		Collections.sort(list1,new MyStringComp());
		System.out.println(list1);
		
		
		
		//this shows that if our Arvind class is not implementing Comparable interface then it 
		//will throws class caste exception
		//because object in keys should be homogeneous and comparable only then it can sort them
		//one should take care of capital and small alphabets as comparable sort on the basis of ASCII value
		//
		TreeMap<Arvind,Integer> hm=new TreeMap<Arvind,Integer>();  
		  
		  hm.put(new Arvind("d"),1);  
		  hm.put(new Arvind("c"),6);  
		  hm.put(new Arvind("a"),2);  
		  hm.put(new Arvind("b"),8);  
		  
		  /*for(Entry<Arvind, Integer> m:hm.entrySet()){  
		   System.out.println("Our HashMap for Test"+m.getKey()+" "+m.getValue()); 
		  }*/
		
		  //for hashCode and equals method verification if we dont override hashcode and equals 
		  //method with user define classes then we will get 
		  //the duplicate items in the hashmap
        Map<Arvind,Integer> hm1=new HashMap<Arvind,Integer>();  
		  
		  hm1.put(new Arvind("a"),1);  
		  hm1.put(new Arvind("c"),6);  
		  hm1.put(new Arvind("a"),2);  
		  hm1.put(new Arvind("b"),8);  
		 
		  for(Entry<Arvind, Integer> m1:hm1.entrySet()){  
			   System.out.println("Our HashMap for Test222  "+m1.getKey()+" "+m1.getValue()); 
			  }
		  
		/*for (Empl e : list) {
			System.out.println(e);
		}*/
		
		
		//uncomment this code if you wish to sort this String type list as String already 
		  //implements Comparable so no need to pass any comparator		
		
		/*List<String> stringList = new ArrayList<String>();
		stringList.add("Crish");
		stringList.add("Stane");
		stringList.add("Siprus");
		stringList.add("Adam");
*/		
		//Collections.sort(stringList);
		//System.out.println(stringList);
		//Collections.sort(stringList,new MyStringComp());	
		//System.out.println(stringList);
	
	}

}

//comparator for sorting on the basis of salary
class MySalaryComp implements Comparator<Empl> {

	@Override
	public int compare(Empl e1, Empl e2) {
		if (e1.getSalary() > e2.getSalary()) {
			return 1;
		} else {
			return -1;
		}
	}
}


class MyStringComp implements Comparator<String> {

	@Override
	public int compare(String o1, String o2) {
		if (o1.compareTo(o2) >1){
			return -1;
		}
		if(o1.compareTo(o2) <1){
			return 1;
		}
		else
			return 0;
	}

}

//comparator for sorting on the basis of names
class MyNameComp implements Comparator<Empl> {

	@Override
	public int compare(Empl e1, Empl e2) {
		return e1.getName().compareTo(e2.getName());

	}
}

class MyNameComp1 extends Empl  {

	public MyNameComp1(String n, int s) {
		super(n, s);
	}

	@Override
	public int compareTo(Empl o) {
		return this.getName().compareTo(o.getName());
	}

	
}



class Empl implements Comparable<Empl>{
	private String name;
	private int salary;

	public Empl(String n, int s) {
		this.name = n;
		this.salary = s;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getSalary() {
		return salary;
	}

	public void setSalary(int salary) {
		this.salary = salary;
	}

	public String toString() {
		return "Name: " + this.name + "-- Salary: " + this.salary;
	}

	@Override
	public int compareTo(Empl o) {
		if(this.getSalary()>o.getSalary())
			return 1;
		else 
			return -1;


	}
	
}
	


	//this class's object needs to be put in HashMap to be sorted according to alphabetically DNSO
	class Arvind implements Comparable<Arvind>{
		private String name;

		public Arvind(String n) {
			this.name = n;
		}

		@Override
		public int hashCode() {
			final int prime = 31;
			int result = 1;
			result = prime * result + ((name == null) ? 0 : name.hashCode());
			return result;
		}

		@Override
		public boolean equals(Object obj) {
			if (this == obj)
				return true;
			if (obj == null)
				return false;
			if (getClass() != obj.getClass())
				return false;
			Arvind other = (Arvind) obj;
			if (name == null) {
				if (other.name != null)
					return false;
			} else if (!name.equals(other.name))
				return false;
			return true;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		
		public String toString() {
			return "Name: " + this.name ;
		}

		@Override
		public int compareTo(Arvind arg0) {
			return this.getName().compareTo(arg0.getName());
		}

			
}

