package com.infotech.client;

import java.util.Comparator;

import com.infotech.model.Person;

public class PersonNameSorter implements Comparator<Person> {

	@Override
	public int compare(Person o1, Person o2) {
		return o1.getName().compareTo(o2.getName());
	}

}
