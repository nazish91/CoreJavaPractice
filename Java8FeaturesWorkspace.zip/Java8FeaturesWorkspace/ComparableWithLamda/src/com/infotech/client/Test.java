package com.infotech.client;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;

import com.infotech.model.Person;

public class Test {

	public static void main(String[] args) {

		List<Person> personList = new ArrayList<>();
		personList.add(new Person(783453, "Kishan", "Male"));
		personList.add(new Person(755535, "Raj", "Male"));
		personList.add(new Person(381332, "Nazish", "Male"));
		personList.add(new Person(78340381, "Ajay", "Male"));
		
		//sortByAnonymousComparatorClass(personList);
		//Collections.sort(personList, new PersonNameSorter());
		//sortByComparatorUsingLamda1(personList);
		sortByComparatorUsingLamda2(personList);
		
	}

	private static void sortByComparatorUsingLamda2(List<Person> personList) {

		Collections.sort(personList, (o1,o2)-> {return o1.getName().compareTo(o2.getName());});
		//personList.forEach(p ->{System.out.println(p);});
		personList.forEach(System.out::println);
	}

	private static void sortByComparatorUsingLamda1(List<Person> personList) {

		Collections.sort(personList, (o1,o2)-> {return o1.getName().compareTo(o2.getName());});
		personList.forEach(new Consumer<Person>() {

			@Override
			public void accept(Person p) {
				System.out.println(p);
			}
		});
	}

	private static void sortByAnonymousComparatorClass(List<Person> personList) {
		Collections.sort(personList, new Comparator<Person>() {

			@Override
			public int compare(Person o1, Person o2) {
				return o1.getName().compareTo(o2.getName());
			}
		});
		
		for(Person p:personList){
			System.out.println(p);
		}
	}

}
