package com.infotech.model;

public class Person {
 private Integer id;
 private String name;
 private String gender;
public Person(Integer id, String name, String gender) {
	super();
	this.id = id;
	this.name = name;
	this.gender = gender;
}

public Integer getId() {
	return id;
}
public String getName() {
	return name;
}

public String getGender() {
	return gender;
}


@Override
public String toString() {
	return "Person [id=" + id + ", name=" + name + ", gender=" + gender + "]";
}
 
 
}
