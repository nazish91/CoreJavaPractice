package com.infotech;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;

public class Test {

	public static void main(String[] args) {
		//IterateMapWithoutLamda();
		IterateMapWithLamda();
		
	}

	private static void IterateMapWithLamda() {
		Map<Integer,String> map = new HashMap<>();
		
		map.put(1001, "Kishan");
		map.put(1002, "Nazish");
		
		//map.forEach((Integer k,String v)-> {System.out.println(k+"\t"+v);
		map.forEach((k,v)-> {System.out.println(k+"\t"+v);
			}
		);
	}

	private static void IterateMapWithoutLamda() {
		Map<Integer,String> map = new HashMap<>();
		
		map.put(1001, "Kishan");
		map.put(1002, "Nazish");
		
		map.forEach(new BiConsumer<Integer,String>() {

			@Override
			public void accept(Integer k,String v) {
				System.out.println(k+"\t"+v);
			}
		});
	}

}
