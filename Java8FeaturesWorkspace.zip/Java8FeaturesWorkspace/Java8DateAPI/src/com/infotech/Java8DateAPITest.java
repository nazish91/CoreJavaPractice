package com.infotech;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class Java8DateAPITest {

	public static void main(String[] args) {
		
		LocalDate localDate = LocalDate.now();
		System.out.println(localDate);
		
		String format = localDate.format(DateTimeFormatter.ofPattern("dd-MM-yy"));
		
		System.out.println(format);
		
		LocalDate localDate2 = LocalDate.of(2016, 8, 15);
		System.out.println(localDate2);
		
		LocalDate localDate3 = LocalDate.now(ZoneId.of("America/Chicago"));
		System.out.println(localDate3);
		
	}

}
