package com.infotech;

import java.text.SimpleDateFormat;
import java.util.Date;

public class BeforeJava8DateTest {

	public static void main(String[] args) {
		Date date = new Date();
		
		System.out.println(1900+date.getYear());
		System.out.println(date.getMonth());
		
		System.out.println(date);
		
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		String format = dateFormat.format(date);
		System.out.println(format);
	}

}
