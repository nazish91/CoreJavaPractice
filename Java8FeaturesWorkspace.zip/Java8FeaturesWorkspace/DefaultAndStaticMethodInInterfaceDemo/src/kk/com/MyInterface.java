package kk.com;

public interface MyInterface {

	default public void welcome(){
		System.out.println("Default method is invoked...");
	}
  
   public static void hello(){
		System.out.println("Static method is invoked...");
	}
   public abstract void greet();
}
