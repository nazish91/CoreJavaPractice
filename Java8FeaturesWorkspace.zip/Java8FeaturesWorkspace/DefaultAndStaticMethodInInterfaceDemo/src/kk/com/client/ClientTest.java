package kk.com.client;

import kk.com.MyInterface;

public class ClientTest implements MyInterface {

	public static void main(String[] args) {
		MyInterface.hello();
		MyInterface interface1 = new ClientTest();
		interface1.welcome();
		interface1.greet();
		
	}

	@Override
	public void greet() {
		System.out.println("Greeting...");
	}
	@Override
	public void welcome(){
		System.out.println("Overrided Default method is invoked...");
	}

}
