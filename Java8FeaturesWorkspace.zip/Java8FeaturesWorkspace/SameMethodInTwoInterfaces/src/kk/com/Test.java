package kk.com;

public class Test implements MyInterface1,MyInterface2{

	public static void main(String[] args) {
		new Test().welcome();
	}
	@Override
	public void welcome() {
		MyInterface2.super.welcome();
		MyInterface1.super.welcome();
	}
}
