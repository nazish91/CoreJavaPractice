package kk.com;

public interface MyInterface2 {

	default void welcome(){
		System.out.println("welcome2");
	}
}
