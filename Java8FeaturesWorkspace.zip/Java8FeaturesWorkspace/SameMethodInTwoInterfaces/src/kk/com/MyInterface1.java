package kk.com;

public interface MyInterface1 {
	default void welcome(){
		System.out.println("welcome1");
	}
}
