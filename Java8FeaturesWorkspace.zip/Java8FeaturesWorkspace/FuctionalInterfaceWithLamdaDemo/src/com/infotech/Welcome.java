package com.infotech;

@FunctionalInterface
public interface Welcome {
	public abstract String welcome(String name, int age);
	//void test();
}
