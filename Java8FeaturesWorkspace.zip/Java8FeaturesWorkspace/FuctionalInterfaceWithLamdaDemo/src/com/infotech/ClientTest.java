package com.infotech;

public class ClientTest {

	public static void main(String[] args) {
		//greetByAnonymousClass();
		Welcome welcome = (name,age) ->{return "Hello,"+name+" You are "+age+" Old..";};
		System.out.println(welcome.welcome("Nazish", 25));
		
		System.out.println("-------------------------------------------------------");
		Greeting greeting = ()->System.out.println("Greet...");
		greeting.greet();
		greeting.welcome();
		
		System.out.println("-----------------------------------");
		//threadWithAnonymousClass();
		threadWithLamdaClass();
	}

	private static void threadWithLamdaClass() {
		Runnable runnable = ()->System.out.println("Thread is running..");
		Thread thread = new Thread(runnable);
		thread.start();
	}

	private static void threadWithAnonymousClass() {
		Runnable runnable = new Runnable() {
			
			@Override
			public void run() {
				System.out.println("Thread is running..");
			}
		};
		
		Thread thread = new Thread(runnable);
		thread.start();
	}

	private static void greetByAnonymousClass() {
		Greeting greeting = new Greeting() {
			
			@Override
			public void greet() {
				System.out.println("Greet...");
			}
		};
		greeting.greet();
	}
}
