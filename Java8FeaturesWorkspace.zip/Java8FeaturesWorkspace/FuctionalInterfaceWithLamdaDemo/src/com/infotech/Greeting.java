package com.infotech;

@FunctionalInterface
public interface Greeting {
	void greet();
	// void test();//If u uncomment it then u will get compilation error

	default void welcome() {
		System.out.println("Welcome");
	}
	
	static void welcome2() {
		System.out.println("welcome2");
	}
}
