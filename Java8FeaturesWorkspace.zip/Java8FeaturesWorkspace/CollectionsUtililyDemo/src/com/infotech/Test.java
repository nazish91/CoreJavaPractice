package com.infotech;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;

public class Test {

	public static void main(String[] args) {

		List<Integer> firstList = new ArrayList<>();
		List<Integer> secondList = new ArrayList<>();
		
		firstList.add(800);
		firstList.add(80);
		firstList.add(90);
		firstList.add(45);
		firstList.add(100);
		firstList.add(400);
		
		secondList.add(300);
		secondList.add(60);
		secondList.add(900);
		secondList.add(450);
		secondList.add(1000);
		
		int binarySearch = Collections.binarySearch(firstList, 45);
		int binarySearch2 = Collections.binarySearch(firstList, 80);
		System.out.println("First List:"+firstList);
		System.out.println("Second List:"+secondList);
		System.out.println("Search 45 in first list:"+binarySearch);
		System.out.println("Search 80 in first list:"+binarySearch2);
		
		int binarySearch3 = Collections.binarySearch(firstList, 8000);
		int binarySearch4 = Collections.binarySearch(firstList, 9000);
		System.out.println("Search 8000 in first list:"+binarySearch3);
		System.out.println("Search 9000 in first list:"+binarySearch4);
		
		System.out.println("------------------------------------");
		boolean disjoint1 = Collections.disjoint(firstList, secondList);
		System.out.println("Disjoint of firstList and secondList:"+disjoint1);
		Collections.copy(firstList, secondList);
		
		System.out.println("Now after copying secondList into firstList:::The firstList:"+firstList);
		
		boolean disjoint = Collections.disjoint(firstList, secondList);
		System.out.println("Disjoint of firstList and secondList:"+disjoint);
		
		List<Integer> list = Collections.unmodifiableList(secondList);
		System.out.println(list);
		
		Enumeration<Integer> enumeration = Collections.enumeration(firstList);
		while(enumeration.hasMoreElements()){
			System.out.println(enumeration.nextElement());
		}
		
		//list.add(123);
	}

}
