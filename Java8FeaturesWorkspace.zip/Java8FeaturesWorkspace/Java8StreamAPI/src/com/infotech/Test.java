package com.infotech;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

public class Test {

	public static void main(String[] args) {
		List<Integer> intList = new ArrayList<>();
		
		intList.add(10);
		intList.add(20);
		intList.add(40);
		intList.add(30);
		intList.add(80);
		intList.add(11);
		
		Stream<Integer> stream = intList.stream();
		stream.forEach(i->System.out.println(i));
		
		System.out.println("-----------------------------------------------");
		Stream<Integer> stream2 = intList.stream();
		long count = stream2.filter(i->i>10).count();
		System.out.println(count);
		
		System.out.println("--------------------------------");
		
		Stream<Integer> parallelStream = intList.parallelStream();
		
		int sum = parallelStream.filter(i->i>10).mapToInt(i->i).sum();
		
		System.out.println("Sum of Num:"+sum);
		
	}

}
