package com.infotech.client;

import com.infotech.model.Address;

public class ClassNotFoundExceptionTest {

	public static void main(String[] args)  {

		Class<?> cls;
		try {
			
//Check the Condition:2 by removing the comments on this
			//cls = Class.forName("com.infotech.model.Address");
			
//Condition:1
//if we notice that we are loading the two classes one is address class and other is unknown class
//Address class definition is already present as we have declared it but the definition of unknown
//class is not there because we have not declared in our project.But as it is looking for a class 
//but fully qualified name only for this reason it will not throw error at compile time .but as unknown 
//class is not declared anywhere then it will throw exception at run time.
			
//Condition2:
//one more way we can generate classNOtFoundException is by going to the location of the address class
//and removing the .class file from workspace and then if we run our code it will throw this exception.
			cls = Class.forName("com.infotech.model.Unknown");
			Object newInstance = cls.newInstance();
			Address address =(Address)newInstance;
			System.out.println(address);
			
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
			e.printStackTrace();
		}
		
	}

}
