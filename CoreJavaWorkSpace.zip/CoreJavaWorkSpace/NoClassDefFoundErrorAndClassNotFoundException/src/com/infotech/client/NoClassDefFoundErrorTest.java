package com.infotech.client;

import com.infotech.model.Address;
import com.infotech.model.Person;

public class NoClassDefFoundErrorTest {

	public static void main(String[] args) {

		Address address = new Address(737837L, "Akshay Park");
		Person person = new Person("Nazish", "Male", 23, address);
		System.out.println(person);
	}
}
