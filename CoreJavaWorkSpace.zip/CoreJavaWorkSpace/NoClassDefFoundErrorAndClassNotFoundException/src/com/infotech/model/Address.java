package com.infotech.model;

public class Address {

	private Long zipCode;
	private String street;
	
	public Address() {
	}
	public Address(Long zipCode, String street) {
		super();
		this.zipCode = zipCode;
		this.street = street;
	}
	public Long getZipCode() {
		return zipCode;
	}
	public String getStreet() {
		return street;
	}
	@Override
	public String toString() {
		return "Address [zipCode=" + zipCode + ", street=" + street + "]";
	}
}
