package com.infotech;

public class Counter {
	private static int count;

	public Counter() {
		count++;
		System.out.println(count);
	}
}
