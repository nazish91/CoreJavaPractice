package com.infotech.client;

import com.infotech.Counter;

public class CounterTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		System.out.println("");
		//only single memory space is given to all the instances of object
		//counter1.couter2,counter3 that is why it is modified every time
		
		Counter counter1 = new Counter();
		Counter counter2 = new Counter();
		Counter counter3 = new Counter();

	}

}
