package com.infotech.client;

public class Test {

	static{
		System.out.println("static block");
	}
	
	static{
		System.out.println("static block2");
	}
	public static void main(String[] args) {
			
		{
		System.out.println("Instance..");	
		}
		System.out.println("Main Method..");
		//main(new String[]{"kk","PK"});

	}

}
