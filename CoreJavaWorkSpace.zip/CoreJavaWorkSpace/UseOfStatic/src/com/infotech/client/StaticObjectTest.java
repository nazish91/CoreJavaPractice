package com.infotech.client;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class StaticObjectTest {
	//static variables are initialized only in static blocks 
	//if we try to initialize them outside static block then it will throw an error
	
	static int a;
	//a=10;
	//similar to static variables static list
	static List<String> list = null;
	static{
		list = new ArrayList<>();
		list.add("Arvind");
		list.add("Nazish");
		
	}
	
	
	public static void main(String[] args) {
		System.out.println(a);
	
		Scanner scanner= new Scanner(System.in);
		System.out.println("Enter you Name:");
		String name = scanner.next();
		list.add(name);
		
		for (String ename : list) {
			System.out.println(ename);
			
		}
		
		System.out.println("Search your name in list:");
		String name2 = scanner.next();
		boolean isPresent = false;
		for (String n : list) {
			if(n.equalsIgnoreCase(name2)){
				isPresent = true;
				break;
			}
		}
		if(isPresent){
			System.out.println("Yes you are present is the list..");
		}else{
			System.out.println("you are not present is the list..");
		}
		scanner.close();
	}

}
