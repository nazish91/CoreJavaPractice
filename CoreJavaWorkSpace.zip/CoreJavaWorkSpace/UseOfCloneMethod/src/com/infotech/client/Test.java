package com.infotech.client;

import com.infotech.model.Employee;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Employee employee1 = new Employee();
		employee1.setAge(30);
		employee1.setName("Nazish");
		System.out.println(employee1);
		
		try {
			Employee employee2 =(Employee)employee1.clone();
			System.out.println(employee2);
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
	}

}
