package com.infotech.dao;

public interface EmployDao {
	public void getInfo();

}
