package com.infotech.dao.impl;

import com.infotech.dao.AdminDao;
import com.infotech.dao.EmployDao;

public class InfotechImpl implements AdminDao,EmployDao{

	
//method getinfo()'s super implementation will point to the method whose 
//interface name we have defined first i.e. AdminDao.
//if we change the order then it will point to EmployDao
	@Override
	public void getInfo() {
		System.out.println("Info");
	}
}
