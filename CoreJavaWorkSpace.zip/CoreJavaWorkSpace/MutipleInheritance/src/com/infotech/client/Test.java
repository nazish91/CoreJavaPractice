package com.infotech.client;

import com.infotech.dao.AdminDao;
import com.infotech.dao.EmployDao;
import com.infotech.dao.impl.InfotechImpl;

public class Test {


	public static void main(String[] args) {
		
		InfotechImpl infotechImpl = new InfotechImpl();
		infotechImpl.getInfo();
		
		AdminDao adminDao = new InfotechImpl();
		adminDao.getInfo();
		
		EmployDao employDao =  new InfotechImpl();
		employDao.getInfo();

	}

}
