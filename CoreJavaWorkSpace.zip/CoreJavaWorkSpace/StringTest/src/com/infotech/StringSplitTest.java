package com.infotech;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.infotech.model.Student;

public class StringSplitTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		List<Student> stuList = getListOfStudentsFromFile();
		for (Student student : stuList) {
			System.out.println(student);
		}
	}

	private static List<Student> getListOfStudentsFromFile() {
		Scanner scanner = null;
		List<Student> stuList = new ArrayList<>();
		try {
			 scanner = new Scanner(new File("test"));
			 
			 while(scanner.hasNextLine()){
				 String line = scanner.nextLine();
				 String[] split = line.split(",");
				 for (int i = 0; i < 1; i++) {
					 Student student = new Student(split[0], Integer.parseInt(split[1]), split[2]);
					 stuList.add(student);
				}
			 }
			 
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}finally{
			if(scanner != null)
				scanner.close();
		}
		return stuList;
	}

}
