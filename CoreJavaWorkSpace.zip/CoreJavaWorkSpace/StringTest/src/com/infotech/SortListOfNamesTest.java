package com.infotech;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class SortListOfNamesTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		List<String> list = new ArrayList<String>();
		list.add("Nazish");
		list.add("Ajay");
		list.add("Pk");
		list.add("Kishan");
		list.add("Mohan");
		
		Collections.sort(list);
		for (String name : list) {
			System.out.println(name);
		}
		
	}

}
