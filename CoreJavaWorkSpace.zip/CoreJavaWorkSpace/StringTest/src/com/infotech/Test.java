package com.infotech;

public class Test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String s1 = "Nazish";//1 object will be created in String Constant pool area
		String s2 = "Nazish";
		char c22 =s2.charAt(1);
		System.out.println(s2.length());
		System.out.println(c22);
		String s3 = new String("Nazish");//2 Objects will be created one object in heap and another normal memory.
		//String intern = s3.intern();
		String s4 = new String("Nazish");
		
		System.out.println(s3);
		System.out.println(s1==s2);//T
		System.out.println(s1==s3);//F
		System.out.println(s3==s4);//F
		
		System.out.println(s1.equals(s3));//T
		
		StringBuffer b1  = new StringBuffer("Nazish");
		//StringBuffer class does not have its own equals() method so it uses 
		//object class equals()method which only compares addresses(references)
		//bcoz default equals() method of object class will be invoked
		System.out.println(s1.equals(b1));//F
		
		StringBuffer b2  = new StringBuffer("Nazish");
		//bcoz two new different objects
		System.out.println(b1==b2);//F
		System.out.println(b1.equals(b2));//F
		
		//System.out.println(new String(b1).equals(new String(b2)));
		//but Stringbuffer has its toString() implementation so it 
		//will be converted to string and then can be compared as String
		System.out.println(b1.toString().equals(b2.toString()));
		
		//ValueOf
		char c[]={'X','Y','Z'};
		System.out.println(String.valueOf(false));
		System.out.println(String.valueOf(c));
		System.out.println("     Kishan   ".trim());
		
		System.out.println("--------------------------");
		
		String s = "This is split method.";
		System.out.println("--------------------------");
		String[] split = s.split(" ");
		for (String st : split) {
			System.out.println(st);
			
		}
		
		System.out.println("-------------------------------------------");
		String name = "Nazish";
		//System.out.println(String.format("My name is Kishan"+%s));
		
		String str ="My name is khan";
		char[] charArray = str.toCharArray();
		for (char d : charArray) {
			System.out.println(d);
		}
		
		System.out.println("--------------------------------------------");
		
		String join = String.join("Ansari,", ",He is from Pune,","He is 23 years old..","Hi","Hello");
		System.out.println(join);
		
		System.out.println("Java".replace('a', 'e'));
		
		System.out.println("I am here".matches("I am here"));
		
		System.out.println("I am here,I am here".lastIndexOf("here"));
		
		System.out.println("a".compareTo("z"));
	}
	

}
