package com.infotech.model;

public class Student {

	private String name;
	private int age;
	private String location;
	public Student(String name, int age, String location) {
		super();
		this.name = name;
		this.age = age;
		this.location = location;
	}
	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}
	public String getLocation() {
		return location;
	}
	@Override
	public String toString() {
		return "Student [name=" + name + ", age=" + age + ", location="
				+ location + "]";
	}
	
	
}
