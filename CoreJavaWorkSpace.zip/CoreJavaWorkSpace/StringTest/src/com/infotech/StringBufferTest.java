package com.infotech;

public class StringBufferTest {

	public static void main(String[] args) {

		StringBuffer buffer = new StringBuffer();
		System.out.println(buffer.capacity());
		/*buffer.append("My Name is Nazish");
		buffer.append("I am ");
		buffer.append(23);
		buffer.append(" Years old");*/
		buffer.append("qqqqqqqqqqqqqqqqqaaaaaaaaaaaaaaaaaa");
		
		System.out.println(buffer);
		System.out.println(buffer.capacity());
	}

}
