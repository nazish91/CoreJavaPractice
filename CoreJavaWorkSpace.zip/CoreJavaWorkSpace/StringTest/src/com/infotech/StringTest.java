package com.infotech;

public class StringTest {
	
	public static void main(String[] args) {
		String name = "Nazish";
		String str = String.format("My name is %s", name);
		System.out.println(str);
		
	}

}
