package com.infotech.client;

import com.infotech.OuterClass;

public class Test {

	public static void main(String[] args) {

		OuterClass outerClass = new OuterClass();
		outerClass.display();
		
		OuterClass.InnerClass inOut = new OuterClass().new InnerClass();
		inOut.welcome();
	}
}
