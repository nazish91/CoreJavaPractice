package com.infotech;

public class OuterClass {//OuterClass.class
	private int data = 1000;
	
	public void display(){
		System.out.println("Data:"+data);
	}
	
	 public static class InnerClass{//OuterClass$InnerClass.class
		 private int x= 2000;
		 
		 public void welcome(){
			 System.out.println("Welcome");
			 System.out.println("x:"+x);
			 new OuterClass().display();
		 }
		 
		 public static void hello(){
			 System.out.println("Hello");
		 }
	}
}
