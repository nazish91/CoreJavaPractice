package com.infotech;

import com.infotech.model.Employee;
import com.infotech.model.Person;

public class Test {

	public static void main(String[] args) {

		//Person person = new Person("kl", 30);
		Employee employee = new Employee("kl", 30);
		employee.Call();
		employee.display();
		
		
//abc method will return the fully qualified name of that class with which 
//object we are calling this abc method
//suppose if we call this method with person.abc() then it will return person's
//class name else if by employee then will return the employee class name
		employee.abc();
//class name that it returns is object specific
		
	}

}
