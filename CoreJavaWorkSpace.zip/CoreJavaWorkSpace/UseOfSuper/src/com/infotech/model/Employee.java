package com.infotech.model;

public class Employee extends Person{

	public Employee(String name, int age) {
		

		super(name, age);
//if 3rd par (data) is present in sub class(employee) then super const. data will 
//point to instance variable of employee class else to super class's data varb.
		
		//super(name, age, data);
		
//here we are passing three parm of super class but in sub class(Employee) Constructor 
//we are only passing two parm.so we know that we will be passing some values also to name and age while calling
//Employee constructor(Two parm name and age).but parm data has to be picked from instance variable of person now 
//only static variables will be given the default value(0).At the time class loading (i.e. when constructor of person and will be called)
//but non static variable data will not be given the default value as we are calling two parm Constructor of Person So anyway data will not be initialized and will not 
//not be given the default value but if it was a static variable(class level) then it will definitely be given the default value and default value will be passed as parm 
//in that constructor and our problem will be solved.for this reason only that instance variable has to be static.
//
	}

	private String email;
	private String panNo;
//if we uncomment this and 3 varb. constructor then it data will point to this var.	
//private int data=100;
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPanNo() {
		return panNo;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	
	public void display(){
		System.out.println(getClass().getName()+":"+"display () Method..");
	}
	
	public void Call(){
		System.out.println(super.getData());
		System.out.println(super.getAge());
		System.out.println(super.getName());
		super.display();
	}
}
