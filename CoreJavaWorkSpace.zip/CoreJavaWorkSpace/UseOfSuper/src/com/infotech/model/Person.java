package com.infotech.model;

public class Person {
	
	private String name;
	private int age;
	
	//if we are calling three parameter constructor and third parameter is 
	//not there in sub class as instance variable then thied par(data) will point to 
	//instance variable of super class n it has to be public or protected or default 
	//to be within its scope and has to be static constructor will be requiring value 
	//when it is called and static variables are given values at the time of class
	//loading so default value(0) will be provided to super constructor in this way
	//if data is passed as param then it is not requiured.
	
	
	protected static int data;
	
	public Person(String name, int age,int data) {
		this.name = name;	
		this.age = age;
		this.data=data;
	}
	
	public Person(String name, int age) {
		this.name = name;	
		this.age = age;
		this.data=data;
	}
	
	
	public String getName() {
		return name;
	}
	public int getAge() {
		return age;
	}
	
	public int getData() {
		return data;
	}
	public void display(){
		System.out.println(getClass().getName()+":"+"display () Method." +name);
	}
	
	public void abc()
	{
		System.out.println(getClass().getName());
	}
	
	
}
