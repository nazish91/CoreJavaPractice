package com.infotech;

public class Test {

	public static void main(String[] args) {
	
		String[] b =args;
		System.out.println(args);
		for (String arg : args) {
			System.out.println(arg);
			Test t =new Test();
			t.aloo();
		}
	}
	public static int neck(int a)
	{
		
	int b=a*10;	
	return b;
		
		
	}
	
	
	public void aloo() {
		String[] args = {"rajeev","aloo"};
		//System.out.println(Test.main(args));
		System.out.println(neck(10));
		//System.out.println("raju");
	}

}
