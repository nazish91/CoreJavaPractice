package com.infotech;


//We can call the main method just like we are calling here in our code
//but code will face the Stack overflow error as if u see carefully we are
//creating the constructor of class B()which in return calling the main method
//and then again when we invoke main method it again creates the constructor 
//of class B() and this will go infinite and will go out of memory.
public class B
{
  B()
  {
    while(A.i<8)
    {
      String a[]={"Main","Checking"};
      A.main(a);
    }
    //System.exit(0);
  }

}

