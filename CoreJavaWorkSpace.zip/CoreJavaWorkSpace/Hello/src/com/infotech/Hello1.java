package com.infotech;
//we only required to import the package if we want to use the state and behaviour of
//a class that is present in some other package.
//if that class is present in the same package then there is no need to import that class
//because class is already there in that package.


//import com.infotech.A;

public class Hello1 {

	public static void main(String[] args) {
		System.out.println("Hello");
		System.out.println(A.i);
	}
}
