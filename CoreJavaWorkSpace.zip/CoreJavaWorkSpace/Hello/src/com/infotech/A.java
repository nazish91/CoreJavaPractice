package com.infotech;

public class A
{
  public static int i=20;
  public static void main(String args[])
  {
    System.out.println("Hello! World");
    i++;
  }
}