package com.infotech;

public class Person {

	private String name ="Nazish";

	
//and can access outer class's private members as regular inner classes do	
	public void display(){
		
//in the local inner class the only restriction is that a local variable or
//method parameter can be accessed only if it is declared final
//The reason for this restriction relares mainly to multi-threading issue
//and ensures that all such variables have well defined values when accessed from 
//the local inner class
		final int data = 30;
		System.out.println("display..."+name);
		
		class welcome{
			public void hello(){
				new welcome().hello();
//But the local inner class object can not use the local variables(data)of the 
//method in which the local inner class is defined 
				System.out.println(data+"\t"+name);
			}
		}

	}
	
	public static void main(String[] args) {
		Person person = new Person();
		person.display();
	}

}
