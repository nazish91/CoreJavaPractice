package com.infotech.exception;

public class EmailNotValidException extends Exception {

	private static final long serialVersionUID = -2187945502963335278L;
	
	public EmailNotValidException(String errorMessage) {
		super(errorMessage);
	}
}
