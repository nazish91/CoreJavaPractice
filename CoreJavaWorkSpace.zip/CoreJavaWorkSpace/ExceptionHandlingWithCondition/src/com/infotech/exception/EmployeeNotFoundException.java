package com.infotech.exception;

public class EmployeeNotFoundException extends Exception {

	private static final long serialVersionUID = -3768872212385921911L;

	private int errorCode;
	public EmployeeNotFoundException(int errorCode, String errorMessage) {
		super(errorMessage);
		this.errorCode = errorCode;
	}
	public int getErrorCode() {
		return errorCode;
	}
}
