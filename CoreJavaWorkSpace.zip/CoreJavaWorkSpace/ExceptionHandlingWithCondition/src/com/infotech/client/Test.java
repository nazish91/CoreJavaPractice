package com.infotech.client;

import com.infotech.exception.EmailNotValidException;
import com.infotech.exception.EmployeeNotFoundException;
import com.infotech.model.Employee;
import com.infotech.model.EmployeeDAo;

public class Test {

	public static void main(String[] args) {

		EmployeeDAo employeeDAo = new  EmployeeDAo();
		try {
			Employee employee = employeeDAo.getEmployeeByEmail(null);
			if(employee != null)
				System.out.println(employee);
		} catch (EmployeeNotFoundException e) {
			System.out.println(e.getErrorCode());
			System.out.println(e.getMessage());
			e.printStackTrace();
		} catch (EmailNotValidException e) {
			System.out.println(e);
		}
	}

}
