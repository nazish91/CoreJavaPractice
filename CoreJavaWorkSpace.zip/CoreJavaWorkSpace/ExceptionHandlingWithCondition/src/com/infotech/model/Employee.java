package com.infotech.model;

public class Employee {

	private String email;
	private String panNo;
	private String name;
	
	

	public Employee(String email, String panNo, String name) {
		super();
		this.email = email;
		this.panNo = panNo;
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPanNo() {
		return panNo;
	}

	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}

	@Override
	public String toString() {
		return "Employee [email=" + email + ", panNo=" + panNo + "]";
	}
}
