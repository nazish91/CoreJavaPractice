package com.infotech.model;

import java.util.ArrayList;
import java.util.List;

import com.infotech.exception.EmailNotValidException;
import com.infotech.exception.EmployeeNotFoundException;

public class EmployeeDAo {

	static List<Employee> empList=null;
	static{
		
		empList=new ArrayList<Employee>();
		empList.add(new Employee("nazisg@gmail.com","bgppa6385f","Nazish"));
		empList.add(new Employee("kishan.k@gmail.com","ZKIAJK787BB","Kishan"));
		empList.add(new Employee("kanika.g@gmail.com","YHHJJ77H","Kanika"));
	}
	
	public Employee getEmployeeByEmail(String email) throws EmployeeNotFoundException, EmailNotValidException{
		boolean isEmployeeFound = false;
		Employee employee = null;
		if(email == null){
			throw new EmailNotValidException("Email can't be null");
		}
		for(Employee emp:empList){
			if(emp.getEmail().equalsIgnoreCase(email)){
				employee = emp;
				isEmployeeFound = true;
				break;
			}
		}
		
		if(!isEmployeeFound){
			throw new EmployeeNotFoundException(404,"Employee couldn't found with Email:"+email);
		}
		return employee;
		
	}
}
