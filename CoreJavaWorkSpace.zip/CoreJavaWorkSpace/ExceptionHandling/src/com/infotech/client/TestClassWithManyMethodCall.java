package com.infotech.client;

import java.io.FileReader;
import java.io.IOException;

public class TestClassWithManyMethodCall {

	public void m3() throws IOException{
		
		FileReader fileReader = new FileReader("test.txt");
		int data;
		while((data =fileReader.read())!=-1){
			System.out.print((char)data);
		}
		fileReader.close();
		System.out.println("m3");
	}
	
	public void m2() throws IOException{
		this.m3();
		System.out.println("m2");
	}
	
	public void m1() throws IOException{
		this.m2();
		System.out.println("m1");
	}
	public static void main(String[] args) {
		TestClassWithManyMethodCall call = new TestClassWithManyMethodCall();
		try {
			call.m1();
		} catch (IOException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
		
		System.out.println("This is main method..");
	}

}
