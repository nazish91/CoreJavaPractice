package com.infotech.client;

import com.infotech.model.Welcome;

public class Test {

	public static void main(String[] args)  {

		Class<Welcome> cls;
		try {
			cls = (Class<Welcome>) Class.forName("com.infotech.model.Welcome");
			System.out.println(cls);
			
			System.out.println(cls.getName());
			Welcome welcome = cls.newInstance();
			System.out.println(welcome);
			if(welcome != null){
				welcome.welcome();
			}
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
			e.printStackTrace();
		}
		System.out.println("This is main method..");
	}

}
