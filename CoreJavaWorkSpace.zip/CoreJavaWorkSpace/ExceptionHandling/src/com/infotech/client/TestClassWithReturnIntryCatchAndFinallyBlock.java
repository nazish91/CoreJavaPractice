package com.infotech.client;

public class TestClassWithReturnIntryCatchAndFinallyBlock {
	
	public static int test(){
		
		try {
			int a = 20;
			return a;
		} catch (Exception e) {
			return 80;
		}finally{
			return 90;
		}
	}

	public static void main(String[] args) {
		System.out.println(TestClassWithReturnIntryCatchAndFinallyBlock.test());
		

	}

}
