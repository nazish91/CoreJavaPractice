package com.infotech.model;

public class Welcome {
	
	public Welcome() {
	}
	public Welcome(int a) {
	}

	public void welcome(){
		System.out.println("welcome");
	}
}
