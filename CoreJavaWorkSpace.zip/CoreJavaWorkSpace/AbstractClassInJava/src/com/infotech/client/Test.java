package com.infotech.client;

import com.infotech.dao.AdminDao;
import com.infotech.dao.BaseDao;
import com.infotech.dao.EmployDao;
import com.infotech.dao.impl.InfotechImpl;

//extending BaseDao n BaseDao already implementing EmployDao so the remaining methods
//which were not implemented by BaseDao has to be implemented(getInfo and abc).
public class Test extends BaseDao {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		InfotechImpl infotechImpl = new InfotechImpl();
		infotechImpl.getInfo();
		
		AdminDao adminDao = new InfotechImpl();
		adminDao.getInfo();
		
		EmployDao employDao =  new InfotechImpl();
		employDao.getInfo();

	}

	
//method abc() already implemented that is why will not force to implement 
	//abc() method but other methods were abstract so have to be implemented
	@Override
	public void getInfo() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void display2() {
		// TODO Auto-generated method stub
		
	}

}
