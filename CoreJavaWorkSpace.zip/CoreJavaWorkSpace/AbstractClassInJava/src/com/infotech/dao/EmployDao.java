package com.infotech.dao;


//BY default all methods are abstract in interface even if we dont put the abstract
//then also compiler puts abstract before that method.
//method abc() is abstract.
public interface EmployDao {
	public void getInfo();
	public void abc();

}
