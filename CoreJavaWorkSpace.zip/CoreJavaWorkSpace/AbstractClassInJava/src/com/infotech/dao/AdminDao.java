package com.infotech.dao;

public interface AdminDao {
	public void getInfo();
}
