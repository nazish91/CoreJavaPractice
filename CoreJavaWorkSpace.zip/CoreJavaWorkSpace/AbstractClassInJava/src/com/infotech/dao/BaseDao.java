package com.infotech.dao;

public abstract class BaseDao implements EmployDao{

//No need to implement as already implemented.
	public void display1(){
		System.out.println("BaseDao:display()1");
	}
	
//In case of abstract we have to explicitly define if method is abstract or not
//we have defined display1() as concrete method and display2() as abstract method.
	
	//need to implement as abstract
	public abstract void display2();
	
	
//no need to implement as concrete
	public void abc()
	{
		System.out.println("here ");
	}
	
}
