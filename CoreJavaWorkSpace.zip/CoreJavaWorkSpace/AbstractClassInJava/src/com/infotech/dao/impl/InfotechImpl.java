package com.infotech.dao.impl;

import com.infotech.dao.AdminDao;
import com.infotech.dao.EmployDao;

public class InfotechImpl implements AdminDao,EmployDao{

	@Override
	public void getInfo() {
		System.out.println("Info");
	}

	@Override
	public void abc() {
		// TODO Auto-generated method stub
		
	}
}
