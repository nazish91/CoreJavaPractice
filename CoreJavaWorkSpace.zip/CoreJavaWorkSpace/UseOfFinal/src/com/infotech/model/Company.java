package com.infotech.model;

public class Company {

	private static final String companyName = "Wipro";
	private String location;
	
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	
	public String getCompanyName() {
		return companyName;
	}
	

}
