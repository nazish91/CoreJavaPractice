package com.infotech.client;

import java.util.ArrayList;
import java.util.List;

import com.infotech.model.Company;

public class Test {

	public static void main(String[] args) {
		final Company company = new Company();
		 Company company2 = new Company();
		//EveryTime we create new object a new hash value is generated for 
		//which the reference(company/2) holds as reference also is an variable
		//whose value can not be changed if final,now if we assign the new object
		//to the same reference then final keyword will restrict it.
		 
		//company = new Company();
//though we get the duplicate variable error but imagine like primitive variables 
		 //we can not change it.
		 
		 
		System.out.println(company);
		System.out.println(company2);
		company.setLocation("Pune");
		company.setLocation("Mumbai");
		//every time we set the value new value will override the previous one.
		//mumbai will display
		System.out.println(company.getCompanyName()+"\t"+company.getLocation());
		System.out.println(company2.getLocation());
		
		System.out.println("--------------------------");
		
		final List<String> list = new ArrayList<>();
		//consider for ref variable "list" can not assign not object to it.
		//though we can add or remove any number of objects to that arraylist 
		//list=new ArrayList<String>();
		
		list.add("Kishan");
		list.add("Raj");
		//list.remove(0);
		
		for (String name : list) {
			System.out.println(name);
		}
	}

}
