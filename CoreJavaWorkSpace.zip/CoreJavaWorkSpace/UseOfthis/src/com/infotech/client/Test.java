package com.infotech.client;

import com.infotech.model.Employee;


public class Test {

	public static void main(String[] args) {
		Employee employee = new Employee("nazish.cs@gmail.com", "UIIU88787H");
		
		Employee employee2 = new Employee("nazish.cs2007@gmail.com", "UIIU88OOO");
		
		System.out.println(employee);
		employee.testThis();
		
		System.out.println(employee2);
		employee.testThis();
		
	}
}
