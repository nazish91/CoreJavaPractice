package com.infotech.model;

public class Person {

	Employee employee = new Employee(this);
}
