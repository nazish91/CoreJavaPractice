package com.infotech.model;

public class Employee {

	private String email;
	private String panNo;
	private Person person;
	
	public Employee(Person person){
		this.person = person;
	}
	public Employee getEmployee(){
		return this;
	}
	
	public void testThis(){
		System.out.println("**********"+this);
	}
	
	public Employee(String email, String panNo) {
		super();
		this.email = email;
		this.panNo = panNo;
	}

	public Employee() {
		this("KK","PIOIQ5656");
	}
	public String getEmail() {
		return email;
	}

	public String getPanNo() {
		return panNo;
	}

	public void display(){
		this.test();
		System.out.println(getClass().getName()+":"+"display () Method..");
	}
	
	private void test() {
		System.out.println("Testing..");
	}

	@Override
	public String toString() {
		return "Employee [email=" + email + ", panNo=" + panNo + "]";
	}
}
