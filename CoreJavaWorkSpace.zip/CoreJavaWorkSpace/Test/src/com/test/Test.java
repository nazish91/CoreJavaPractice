package com.test;

public class Test {

	public static void main(String[] args) {

		/*boolean b = true;
		String s=String.valueOf(b);
		System.out.println(s);
		
		char c ='A';
		System.out.println((int)c);*/
		
		Class<?> c;
		try {
			c = Class.forName("com.test.Simple");
			c.newInstance();
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
			e.printStackTrace();
		}
		
	}

}
