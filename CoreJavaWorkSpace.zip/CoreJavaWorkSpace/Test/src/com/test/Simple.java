package com.test;

public class Simple {

}
