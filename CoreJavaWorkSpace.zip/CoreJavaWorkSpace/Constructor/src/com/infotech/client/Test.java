package com.infotech.client;

import com.infotech.model.Employee;

public class Test {

	public static void main(String[] args) {
     
		//will not work as we have defined our own constructor(parameterized)
		//can not call default constructor(as Compiler does when we create instance)
		//untill we have defined explicitly a default constructor
		
		/*Employee employee = new Employee();
		
		System.out.println(employee.getEmail()+"\t"+employee.getPassword());*/
		
		System.out.println("-------------------------------");
		
		
		Employee employee2 = new Employee("kishan", "pass");
		System.out.println(employee2.getEmail()+"\t"+employee2.getPassword());
		
	}

}
