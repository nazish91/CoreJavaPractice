package com.infotech.model;

public class Employee {

	private String email;
	private String password;
	
	public Employee(int a) {
		System.out.println("Default Constructor..");
	}
	
	public Employee(String a) {
		System.out.println("Default Constructor for String..");
	}
	
	 public Employee(String email, String password) {
		this("raju");
		//Constructor call has to be the first statement 
		//two this constructor call we can not call
		//this.(10);
		this.email = email;
		this.password = password;
	}
	
	public String getEmail() {
		return email;
	}
	
	public String getPassword() {
		return password;
	}
	
}
