package com.infotech.dao;

public class BaseDao {

	public void display1(){
		System.out.println("BaseDao:display()1");
	}
	
	public void display2(){
		System.out.println("BaseDao:display2()");
	}
}
