package com.infotech.dao;

public class EmployeeDao extends BaseDao {
	
	public void display2(){
		System.out.println("EmployeeDao:display2()");
	}
}
