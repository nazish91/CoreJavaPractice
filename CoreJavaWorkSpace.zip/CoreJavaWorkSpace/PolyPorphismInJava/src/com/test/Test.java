package com.test;

import com.infotech.dao.BaseDao;
import com.infotech.dao.EmployeeDao;

public class Test {

	public static void main(String[] args){
		
		BaseDao baseDao = new EmployeeDao();
		baseDao.display2();
		
		BaseDao baseDao2 = new BaseDao();
		baseDao2.display2();
	}
}
