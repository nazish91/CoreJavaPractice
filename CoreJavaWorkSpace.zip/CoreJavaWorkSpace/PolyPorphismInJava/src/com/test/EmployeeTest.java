package com.test;

import com.infotech.dao.Employee;

public class EmployeeTest {

	public static void main(String[] args) {

		Employee employee1 = new Employee("Nazish", 25);
		
		System.out.println(employee1.getName()+"\t"+employee1.getAge());
		
		try {
			Object clone = employee1.clone();
			if(clone != null){
				Employee employee2 = (Employee)clone;
				System.out.println(employee2.getName()+"\t"+employee2.getAge());
			}
			//if you use the default override method by suggestion then you have to 
			//explicitly type cast the object return to Employee before assigning it to 
			//Employee object
		/*	Employee employee2 = employee1.clone();
			System.out.println(employee2.getName()+"\t"+employee2.getAge());*/
			
       //clone()always gives the deep copy will create the separate objects.
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
	}

}
