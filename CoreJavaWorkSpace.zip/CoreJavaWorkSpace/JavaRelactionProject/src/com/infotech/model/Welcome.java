package com.infotech.model;

public class Welcome {

	private int data = 3000;
	private int data2 = 6000;
	
	private void display(){
		System.out.println("Display..");
	}
	
	public void greet(){
		System.out.println("Greet..");
	}
	public Welcome() {
	}

	 Welcome(int data) {
		super();
		this.data = data;
	}
}
