package com.infotech.client;

import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import com.infotech.model.Welcome;

public class ClientTest {

	public static void main(String[] args) throws InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException, NoSuchFieldException {

		try {
			Class<?> cls =  Class.forName("com.infotech.model.Welcome");
			Object object = cls.newInstance();
			if(object != null){
				Welcome welcome=(Welcome)object;
				welcome.greet();
			}
			Method method = cls.getDeclaredMethod("display");
			
			int parameterCount = method.getParameterCount();
			System.out.println(parameterCount);
			
			Constructor<?>[] declaredConstructors = cls.getDeclaredConstructors();
			for (Constructor<?> constructor : declaredConstructors) {
				constructor.setAccessible(true);
				System.out.println(constructor.getName()+"\t"+constructor.getParameterCount()+"\t"+constructor.getModifiers());
			}
			
			method.setAccessible(true);
			method.invoke(object);
			
			/*Field field = cls.getDeclaredField("data");
			field.setAccessible(true);
			System.out.println(field.get(object));*/
			Field[] declaredFields = cls.getDeclaredFields();
			for (Field field : declaredFields) {
				field.setAccessible(true);
				String name = field.getName();
				System.out.println(name+":"+field.get(object));
			}
		} catch (ClassNotFoundException | NoSuchMethodException | SecurityException e) {
			e.printStackTrace();
		}
	}

}
