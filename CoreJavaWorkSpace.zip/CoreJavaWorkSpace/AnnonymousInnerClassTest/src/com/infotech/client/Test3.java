package com.infotech.client;

public class Test3 {

//This is the example where we have defined the inner class in main method which is static method
//so here we dont need to put static before anonymous class
	public static void main(String[] args) {
		Runnable runnable = new Runnable() {
			
			@Override
			public void run() {
				System.out.println(Thread.currentThread().getName());
				for (int i = 1; i < 5; i++) {
					System.out.println(i);
				}
			}
		};
		
		Thread t1 = new Thread(runnable,"MyTread_1");
		Thread t2 = new Thread(runnable,"MyTread_2");
		t1.start();
		t2.start();
	}

}
