package com.infotech.client;

import com.infotech.dao.EmployeeDao;
import com.infotech.dao.EmployeeDaoImpl;

public class Test {

	public static void main(String[] args) {

		EmployeeDao dao = new EmployeeDaoImpl();
		dao.getEmployeesInfo();
	}

}
