package com.infotech.client;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.infotech.dao.EmployeeDao;

public class Test1 {
	
	
	
//A manual example how our class can have inner class and in similar way we can define our own anonymous class
/*	class A implements EmployeeDao
	{

		@Override
		public void getEmployeesInfo() {
        List<String> ls =new ArrayList<>();
        ls.add("a");
        ls.add("b");
        ls.add("c");
        ls.add("d");
        
        for (String string : ls) {
			System.out.println(string);
		}

			
		}
		
	}*/
	
	//it is anonymous class though we can define it inside main method
	//also then we dont have to assign dao as static
//it can be imagine like a class that is implementing EmployeeDao
//interface, we are  not creating the object of this interface
	static EmployeeDao dao = new EmployeeDao() {
		
		@Override
		public void getEmployeesInfo() {
			List<String> list = new ArrayList<>();
			list.add("KK");
			list.add("PK");
			list.add("JK");
			for (String name : list) {
				System.out.println(name);
			}
		}
	};

	public static void main(String[] args) {

	
		dao.getEmployeesInfo();
//Remove the comments here when we remove the comments from manual inner class A.
		/*Test1 a = new Test1();
		a.new A().getEmployeesInfo();*/
	}
}
