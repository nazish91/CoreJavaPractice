package com.infotech.dao;

public interface EmployeeDao {
 void getEmployeesInfo();
}
