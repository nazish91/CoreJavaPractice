package com.infotech.dao;

import java.util.ArrayList;
import java.util.List;

public class EmployeeDaoImpl implements EmployeeDao {

	@Override
	public void getEmployeesInfo() {

		List<String> list = new ArrayList<>();
		list.add("KK");
		list.add("PK");
		list.add("JK");
		for (String name : list) {
			System.out.println(name);
		}
	}


}
