package com.infotech.model;

public class Employee {

	private String email;
	private String password;
	
	public Employee(String email, String password) {
		this.email = email;
		this.password = password;
	}
	
	public String getEmail() {
		return email;
	}
	
	public String getPassword() {
		return password;
	}
//if we do not override the hashCode and Equals method then we can not compare the 
	//two objects with equals() method,can do that for Strinf coz String is already 
	//Overriding these two methods
	

//if two objects are equal according to the equals(object) method then calling the hashCode()
//method on each of the two objects must produce the same integer result.
	/*@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result
				+ ((password == null) ? 0 : password.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (password == null) {
			if (other.password != null)
				return false;
		} else if (!password.equals(other.password))
			return false;
		return true;
	}*/

	
//also remove the comments below to check the hexadecimal value that is generated without
//overriding the hashcode() and equals() method you will see that two values are different 
//because by default equals method of object class will be invoked which is shallow comparison "=="\
//but when we override the equals method the this method checks for the equals objects
//and return true for them.
	@Override
	public String toString() {
		return "Employee [email=" + email + ", password=" + password + "]";
	}
}
