package com.infotech.client;

import com.infotech.model.Employee;

public class Test {

	public static void main(String[] args) {
		
		StringBuffer buffer= new StringBuffer("nazish");
     
		Employee employee1 = new Employee("nazish.cs@yahoo.com", "pass123");
		Employee employee2 = new Employee("nazish.cs@yahoo.com", "pass123");
		//"==" always compare the reference by making them same will return true on 
		//making both the object's reference equal
		//employee2 = employee1;
		System.out.println(employee1);
		System.out.println(employee2);
		if(employee1==(employee2))
			System.out.println("Both Objects are equal..");
		else
			System.out.println("Both Objects are not equal..");
		
		//test this condition while commenting equals and hashcode method in employee class
		if (employee1.equals(employee2)) {
			System.out.println("yes");
			
		}
		else {
			System.out.println("no");
		}
		
		System.out.println(new String("Kishan").equals(new String("Kishan")));
		System.out.println(new StringBuffer("Kishan").toString().equals(new StringBuffer("Kishan").toString()));
		//As String buffer class does not have its own equals method will use 
		//object class equals method and will return false
		System.out.println(buffer.equals(new StringBuffer("nazish")));
	}

}
