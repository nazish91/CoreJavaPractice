package com.infotech.model;

public class Employee {

	private String email;
	private String password;
	
	public Employee() {
		System.out.println("Default Constructor..");
	}
	
	public Employee(String email, String password) {
		this.email = email;
		this.password = password;
	}
	
	public String getEmail() {
		return email;
	}
	
	public String getPassword() {
		return password;
	}
	
}
