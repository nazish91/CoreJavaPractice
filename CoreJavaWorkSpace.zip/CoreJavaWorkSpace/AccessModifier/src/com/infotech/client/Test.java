package com.infotech.client;

import com.infotech.model2.Person;

public class Test extends Person{
	int data;
//if we uncomment it then this.age and this.name will point to these age and name
//else will point to super class
	/*String name; int age;*/
	public Test(String name, int age,int data) {
		super(name,age);
//this.name/age will point to super class person reason is this(keyword)=(new Test()) is also
//the instance of person as it is extending it if age and  name are not present in Test class 
// then it will point to person class(super class) age and name but data is present in Test
// class then it will point to Test class.
//don't be confused with this keyword for the instance of this class only because 
//this is also the instance of person class because it is extending it
		
		System.out.println(this.name);
		System.out.println(this.age);
		
		this.data = data;
		this.name = name;
		this.age = age;
	}

//have to create this method to understand the concept of inheritance and protected 
//modifier to work accordingly because main method won't allow inheritance to work
	public void abc()
	{
		System.out.println(this.name+"\t"+this.age);
		
	}
	public static void main(String[] args) {
     
//we are in static main method which is not the part of object,static method
//does not care about the inheritance so inheritance and protected access modifier 
//will not work here ,we have to move our code to some method outside the 
//main method eg. abc() then our inheritance concept will work.
		
		/*Person person = new Test("KK", 27,100);
//we can use getter method to access the name and age because getter methods are 
//public not protected
		System.out.println(person.name+"\t"+person.age);*/
		
		Test test = new Test("KK", 27,100);
		System.out.println(test.name+"\t"+test.age+"\t"+test.data);
		test.abc();
		
		
	}

}
