package com.infotech.client;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.infotech.entities.Address;
import com.infotech.entities.Employee;
import com.infotech.util.HibernateUtil;

public class ClientTest {

	public static void main(String[] args) {

		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = null;
		try {
			session = sf.openSession();
			session.beginTransaction();
			
			Employee employee = getEmployee();
			
			session.save(employee);
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session != null)
				session.close();
		}
	}

	private static Employee getEmployee() {
		Employee employee = new Employee();
		employee.setAge(30);
		employee.setDoj(new Date());
		employee.setEmail("kishan.ansari2017@yahoo.com");
		employee.setEmployeeName("Kishan Ansari");
		employee.setSalary(90000.00);
		
		Address address2 = employee.getAddress();
		Address address = new Address();
		address.setCity("Pune");
		address.setStreet("Park Street");
		address.setZipCode(8103939L);
		
		address2.setCity("Pune");
		address2.setStreet("Park Street");
		address2.setZipCode(8103939L);
		
		employee.setAddress(address);
		return employee;
	}

}
