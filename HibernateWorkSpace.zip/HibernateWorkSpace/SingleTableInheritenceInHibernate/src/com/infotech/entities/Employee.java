package com.infotech.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.DynamicUpdate;

@Entity
@Table(name="employee_table")
@DynamicUpdate
@DiscriminatorValue(value = "e")
public class Employee extends Person {
	
	@Column(name = "salary")
	private Double salary;
	
	@Column(name = "email",length=50,unique=true)
	private String email;
	
	@Column(name = "date_of_joining")
	@Temporal(TemporalType.DATE)
	private Date doj;
	
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Date getDoj() {
		return doj;
	}
	public void setDoj(Date doj) {
		this.doj = doj;
	}
	@Override
	public String toString() {
		return "Employee [salary=" + salary + ", email=" + email + ", doj="
				+ doj + "]";
	}
}
