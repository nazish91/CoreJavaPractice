package com.infotech.client;

import java.text.ParseException;
import java.util.Scanner;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.infotech.entities.Employee;
import com.infotech.entities.Pancard;
import com.infotech.util.HibernateUtil;

public class FetchDataClientTest {

	public static void main(String[] args) throws ParseException {
	SessionFactory sf = HibernateUtil.getSessionFactory();
	Session session = null;
	Scanner scanner = null;
	try {
		session = sf.openSession();
		scanner = new Scanner(System.in);
		System.out.println("Enter Employee ID::");
		int employeeId = scanner.nextInt();
		
		Employee employee =(Employee) session.get(Employee.class, employeeId);
		if(employee != null){
			System.out.println(employee);
			Pancard pancard = employee.getPancard();
			if(pancard != null)
				System.out.println(pancard);
		}else {
			System.out.println("Employee not found with ID::"+employeeId);
		}
		
	} catch (Exception e) {
		e.printStackTrace();
	}finally{
		if(session != null)
			session.close();
	}

	}

}
