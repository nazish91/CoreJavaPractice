package com.infotech.client;

import java.text.ParseException;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.infotech.entities.Address;
import com.infotech.entities.Employee;
import com.infotech.entities.Pancard;
import com.infotech.util.HibernateUtil;

public class ClientTest {

	public static void main(String[] args) throws ParseException {
		
	SessionFactory sf = HibernateUtil.getSessionFactory();
	Session session = null;
	try {
		session = sf.openSession();
		session.beginTransaction();

		Employee employee = new Employee();
		employee.setAge(30);
		employee.setDoj(new Date());
		employee.setEmail("KK.ansari2017@yahoo.com");
		employee.setEmployeeName("KK Ansari");
		employee.setSalary(50000.00);
		
		Pancard pancard = new Pancard();
		pancard.setDob(HibernateUtil.getDob("20/01/1989"));
		pancard.setPanHolderName("KK Ansari");
		pancard.setPanNo("KHJS8003RA");
		employee.setPancard(pancard);
		
		Address address1 = new Address();
		address1.setCity("Pune");
		address1.setStreet("Park Street");
		address1.setZipCode(9038238L);
		
		Address address2 = new Address();
		address2.setCity("Mumbai");
		address2.setStreet("Park Street2");
		address2.setZipCode(9038200L);
		
		Address address3 = new Address();
		address3.setCity("Mumbai");
		address3.setStreet("Park Street2");
		address3.setZipCode(9038200L);
		
		employee.getAddressList().add(address1);
		employee.getAddressList().add(address2);
		employee.getAddressList().add(address3);
		
		session.save(employee);
		
		session.getTransaction().commit();
	} catch (Exception e) {
		e.printStackTrace();
	}finally{
		if(session != null)
			session.close();
	}

	}


}
