package com.infotech.client;

import java.util.Date;

import com.infotech.dao.EmployeeDAO;
import com.infotech.dao.impl.EmployeeDAOImpl;
import com.infotech.entities.Employee;

public class ClientTest {

	public static void main(String[] args) {
		EmployeeDAO employeeDAO = new EmployeeDAOImpl();
		//createEmployee(employeeDAO);
		//employeeDAO.updateEmailByEmployeeId(2, "kishan.ansari2013@yahoo.com");
		//employeeDAO.getEmployeeById(20);
		employeeDAO.deleteEmployeeById(2);
		
	}

	private static void createEmployee(EmployeeDAO employeeDAO) {
		Employee employee = new Employee();
		employee.setAge(30);
		employee.setDoj(new Date());
		employee.setEmail("kishan.ansari2017@yahoo.com");
		employee.setEmployeeName("Kishan Ansari");
		employee.setSalary(90000.00);
		
		employeeDAO.createEmployee(employee);
	}
}
