package com.infotech.dao.impl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.infotech.dao.EmployeeDAO;
import com.infotech.entities.Employee;
import com.infotech.util.HibernateUtil;

public class EmployeeDAOImpl implements EmployeeDAO {

	public void createEmployee(Employee employee) {

		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = null;
		try {
			session = sf.openSession();
			session.beginTransaction();
			
			session.save(employee);
			
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session != null)
				session.close();
		}
	}

	public Employee getEmployeeById(int employeeId) {

		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = null;
		try {
			session = sf.openSession();
			
			Object object = session.get(Employee.class, employeeId);
			if(object != null){
				Employee employee=(Employee)object;
				System.out.println(employee);
			}else {
				System.out.println("Employee not found with ID:"+employeeId);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session != null)
				session.close();
		}
		return null;
	}

	public void updateEmailByEmployeeId(int employeeId, String newEmail) {

		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = null;
		try {
			session = sf.openSession();
			
			Object object = session.get(Employee.class, employeeId);
			if(object != null){
				session.beginTransaction();
				Employee employee=(Employee)object;
				employee.setEmail(newEmail);
				session.update(employee);
				session.getTransaction().commit();
			}else {
				System.out.println("Employee not found with ID:"+employeeId);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session != null)
				session.close();
		}
	
	}

	public void deleteEmployeeById(int employeeId) {

		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = null;
		try {
			session = sf.openSession();
			
			Object object = session.get(Employee.class, employeeId);
			if(object != null){
				session.beginTransaction();
				Employee employee=(Employee)object;
				session.delete(employee);
				session.getTransaction().commit();
			}else {
				System.out.println("Employee not found with ID:"+employeeId);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session != null)
				session.close();
		}
	}
}
