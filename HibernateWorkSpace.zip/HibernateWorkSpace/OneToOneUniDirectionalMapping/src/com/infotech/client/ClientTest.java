package com.infotech.client;

import java.text.ParseException;
import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.infotech.entities.Employee;
import com.infotech.entities.Pancard;
import com.infotech.util.HibernateUtil;

public class ClientTest {

	public static void main(String[] args) throws ParseException {
		
	Employee employee = getEmployee();

	SessionFactory sf = HibernateUtil.getSessionFactory();
	Session session = null;
	try {
		session = sf.openSession();
		session.beginTransaction();
		
		session.save(employee);
		
		session.getTransaction().commit();
	} catch (Exception e) {
		e.printStackTrace();
	}finally{
		if(session != null)
			session.close();
	}

	}

	private static Employee getEmployee() throws ParseException {
		Employee employee = new Employee();
		employee.setAge(30);
		employee.setDoj(new Date());
		employee.setEmail("Nazish.ansari2017@yahoo.com");
		employee.setEmployeeName("Nazish Ansari");
		employee.setSalary(90000.00);
		
		Pancard pancard = new Pancard();
		pancard.setDob(HibernateUtil.getDob("20/01/1989"));
		pancard.setPanHolderName("Nazish Ansari");
		pancard.setPanNo("KHJS8DARA");
		
		employee.setPancard(pancard);
		return employee;
	}

}
