package com.infotech.entities;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="pancard_table")
public class Pancard {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="pancard_id")
	private Integer id;
	
	@Column(name="pan_no",length=60)
	private String panNo;
	
	@Column(name="date_of_birth")
	private Date dob;
	
	@Column(name="pan_holder_name",length=60)
	private String panHolderName;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getPanNo() {
		return panNo;
	}
	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}
	public Date getDob() {
		return dob;
	}
	public void setDob(Date dob) {
		this.dob = dob;
	}
	public String getPanHolderName() {
		return panHolderName;
	}
	public void setPanHolderName(String panHolderName) {
		this.panHolderName = panHolderName;
	}
	@Override
	public String toString() {
		return "Pancard [id=" + id + ", panNo=" + panNo + ", dob=" + dob
				+ ", panHolderName=" + panHolderName + "]";
	}
}
