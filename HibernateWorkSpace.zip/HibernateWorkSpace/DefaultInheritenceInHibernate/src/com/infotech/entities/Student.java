package com.infotech.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="student_table")
public class Student extends Person {

	@Column(name="school_name",length=60)
	private String schoolName;
	
	@Column(name="student_phone",length=60)
	private Long studentPhone;
	
	@Column(name="class_name",length=60)
	private String className;

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public Long getStudentPhone() {
		return studentPhone;
	}

	public void setStudentPhone(Long studentPhone) {
		this.studentPhone = studentPhone;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}
}
