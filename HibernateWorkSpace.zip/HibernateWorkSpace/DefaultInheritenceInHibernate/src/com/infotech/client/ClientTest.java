package com.infotech.client;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.infotech.entities.Employee;
import com.infotech.entities.Person;
import com.infotech.entities.Student;
import com.infotech.util.HibernateUtil;

public class ClientTest {

	public static void main(String[] args) {
		Employee employee = new Employee();
		employee.setName("Nazish");
		employee.setAge(23);
		employee.setGender("Male");
		employee.setDoj(new Date());
		employee.setEmail("kishan.ansari2017@yahoo.com");
		employee.setSalary(90000.00);
		
		Student student = new Student();
		student.setName("Tanuj");
		student.setAge(23);
		student.setClassName("12th Std");
		student.setGender("Male");
		student.setSchoolName("DPS");
		student.setStudentPhone(902838333L);
		
		Person person = new Person();
		person.setAge(24);
		person.setGender("Female");
		person.setName("Priya");
		
		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = null;
		try {
			session = sf.openSession();
			session.beginTransaction();
			
			session.save(person);
			session.save(employee);
			session.save(student);
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session != null)
				session.close();
		}
	
		
		
		
	}
}
