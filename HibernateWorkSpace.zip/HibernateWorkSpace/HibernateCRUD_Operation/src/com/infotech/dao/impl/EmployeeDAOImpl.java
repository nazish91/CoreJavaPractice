package com.infotech.dao.impl;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.infotech.dao.EmployeeDAO;
import com.infotech.entities.Employee;
import com.infotech.util.HibernateUtil;

public class EmployeeDAOImpl implements EmployeeDAO {

	public void createEmployee(Employee employee) {

		SessionFactory sf = HibernateUtil.getSessionFactory();
		Session session = null;
		try {
			session = sf.openSession();
			session.beginTransaction();
			
			session.save(employee);
			
			session.getTransaction().commit();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(session != null)
				session.close();
		}
	}

	public Employee getEmployeeById(int employeeId) {
		return null;
	}

	public void updateEmailByEmployeeId(int employeeId, String newEmail) {

	}

	public void deleteEmployeeById(int employeeId) {

	}

}
