package com.infotech.dao;

import com.infotech.entities.Employee;

public interface EmployeeDAO {

	public abstract void createEmployee(Employee employee);
	public abstract Employee getEmployeeById(int employeeId);
	public abstract void updateEmailByEmployeeId(int employeeId,String newEmail);
	public abstract void deleteEmployeeById(int employeeId);
}
