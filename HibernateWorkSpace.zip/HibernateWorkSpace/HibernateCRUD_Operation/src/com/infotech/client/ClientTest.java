package com.infotech.client;

import java.util.Date;

import com.infotech.dao.EmployeeDAO;
import com.infotech.dao.impl.EmployeeDAOImpl;
import com.infotech.entities.Employee;

public class ClientTest {

	public static void main(String[] args) {
		EmployeeDAO employeeDAO = new EmployeeDAOImpl();
		createEmployee(employeeDAO);
	}

	//doing the work of setting the values in the employee object 
	private static void createEmployee(EmployeeDAO employeeDAO) {
		Employee employee = new Employee();
		employee.setEmployeeId(1);
		employee.setAge(23);
		employee.setDoj(new Date());
		employee.setEmail("nazish.ansari2017@yahoo.com");
		employee.setEmployeeName("Nazish Ansari");
		employee.setSalary(90000.00);
		
		//doing the work of persisting the data in the database
		employeeDAO.createEmployee(employee);
	}
}
