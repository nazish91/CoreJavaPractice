package com.infotech.client;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

public class ClientTest {

	@SuppressWarnings("deprecation")
	public static void main(String[] args) {
		
		Student_info student = new Student_info();
		student.setName("nazish1");
		student.setDate(new Date());
		
		Student_info student2 = new Student_info();
		student2.setName("nazish21");
		student2.setDate(new Date());
		
		SessionFactory factory = new AnnotationConfiguration().configure().buildSessionFactory();
		Session session = factory.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(student);
		session.save(student2);
		
		session.getTransaction().commit();
		session.close();
//If we do the closing of session factory explicitly then (hbm2ddl)create-drop
//would drop the table 
//as compared to drop and create new table in in case of create(hbm2ddl)
	    //factory.close();
	}

	
}
